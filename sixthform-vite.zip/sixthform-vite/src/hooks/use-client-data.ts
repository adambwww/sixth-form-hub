import { useEffect, useState, useCallback } from 'react';
import { seedIfEmpty } from '@/lib/data';

let seeded = false;

/** Runs a data getter on the client only, returning [data, refresh]. */
export function useClientData<T>(getter: () => T, initial: T): [T, () => void] {
  const [data, setData] = useState<T>(initial);
  const [, setTick] = useState(0);
  const refresh = useCallback(() => setTick(t => t + 1), []);
  useEffect(() => {
    if (!seeded) { seedIfEmpty(); seeded = true; }
    setData(getter());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refresh, getter]);
  return [data, refresh];
}
