import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useMemo, useState } from 'react';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Download } from 'lucide-react';
import { getCalendarEvents, type CalendarEvent } from '@/lib/data';

export const Route = createFileRoute('/academic-calendar')({
  component: CalendarPage,
});

const TYPE_COLOR: Record<string, string> = {
  Exam: '#9d3d3d', UCAS: '#c99216', Event: '#1a2d5a', Holiday: '#5a8a3d', SDP: '#8a3d6b', Other: '#5a5a6e',
};
const TYPES = ['Exam','UCAS','Event','Holiday','SDP','Other'];

function CalendarPage() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [filter, setFilter] = useState<Set<string>>(new Set(TYPES));
  const [cursor, setCursor] = useState(() => { const d = new Date(); d.setDate(1); return d; });
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => { setEvents(getCalendarEvents()); }, []);

  const filtered = useMemo(() => events.filter(e => filter.has(e.type)), [events, filter]);
  const upcoming = filtered.filter(e => new Date(e.date) >= new Date(new Date().setHours(0,0,0,0))).slice(0, 5);

  const today = new Date(); today.setHours(0,0,0,0);
  const year = cursor.getFullYear(), month = cursor.getMonth();
  const first = new Date(year, month, 1);
  const firstDay = (first.getDay() + 6) % 7; // Mon=0
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const eventsOn = (d: number) => {
    const date = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    return filtered.filter(e => e.date === date || (e.endDate && e.date <= date && e.endDate >= date));
  };
  const selectedEvents = selected ? filtered.filter(e => e.date === selected) : [];

  const exportIcs = () => {
    const pad = (s: string) => s.replace(/-/g, '');
    const lines = ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Sixth Form Hub//EN'];
    filtered.forEach(e => {
      lines.push('BEGIN:VEVENT');
      lines.push(`UID:${e.id}@sixthformhub`);
      lines.push(`DTSTART;VALUE=DATE:${pad(e.date)}`);
      const end = e.endDate ? new Date(e.endDate) : new Date(e.date);
      end.setDate(end.getDate() + 1);
      lines.push(`DTEND;VALUE=DATE:${end.toISOString().slice(0,10).replace(/-/g,'')}`);
      lines.push(`SUMMARY:${e.title}`);
      lines.push(`DESCRIPTION:${e.description.replace(/\n/g, '\\n')}`);
      lines.push('END:VEVENT');
    });
    lines.push('END:VCALENDAR');
    const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'sixth-form-calendar.ics'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <PageHero eyebrow="Calendar" title="Every date that matters." subtitle="Exams, UCAS deadlines, holidays and events — export anything to your own calendar." />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5">
            {TYPES.map(t => {
              const active = filter.has(t);
              return (
                <button key={t} onClick={() => { const n = new Set(filter); n.has(t) ? n.delete(t) : n.add(t); setFilter(n); }}
                  className={`rounded-full px-3 py-1 text-xs font-medium ${active ? 'text-white' : 'bg-muted opacity-50'}`}
                  style={active ? { backgroundColor: TYPE_COLOR[t] } : undefined}>{t}</button>
              );
            })}
          </div>
          <Button onClick={exportIcs} variant="outline" size="sm"><Download className="mr-1 h-4 w-4" /> Export .ics</Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
          <Card className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-xl font-semibold">{cursor.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</h3>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" onClick={() => setCursor(new Date(year, month - 1, 1))}><ChevronLeft className="h-4 w-4" /></Button>
                <Button variant="outline" size="sm" onClick={() => { const d = new Date(); d.setDate(1); setCursor(d); }}>Today</Button>
                <Button variant="ghost" size="icon" onClick={() => setCursor(new Date(year, month + 1, 1))}><ChevronRight className="h-4 w-4" /></Button>
              </div>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-muted-foreground">
              {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => <div key={d} className="py-2">{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {cells.map((d, i) => {
                if (!d) return <div key={i} />;
                const ev = eventsOn(d);
                const dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
                const isToday = today.getFullYear()===year && today.getMonth()===month && today.getDate()===d;
                const isSelected = selected === dateStr;
                return (
                  <button key={i} onClick={() => setSelected(isSelected ? null : dateStr)} className={`aspect-square rounded-lg p-1 text-left text-sm transition-colors hover:bg-muted ${isSelected ? 'ring-2 ring-gold' : ''}`}>
                    <div className={`mx-auto grid h-7 w-7 place-items-center rounded-full ${isToday ? 'bg-burgundy text-white' : ''}`}>{d}</div>
                    <div className="mt-0.5 flex flex-wrap justify-center gap-0.5">
                      {ev.slice(0, 3).map((e, k) => <span key={k} className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: TYPE_COLOR[e.type] }} />)}
                    </div>
                  </button>
                );
              })}
            </div>
            {selected && (
              <div className="mt-5 border-t pt-4">
                <div className="mb-2 text-sm font-semibold">{new Date(selected).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
                {selectedEvents.length === 0 && <p className="text-sm text-muted-foreground">No events.</p>}
                {selectedEvents.map(e => (
                  <div key={e.id} className="mb-2 rounded-lg border-l-4 bg-muted/30 p-3" style={{ borderColor: TYPE_COLOR[e.type] }}>
                    <div className="flex items-center gap-2"><Badge variant="outline">{e.type}</Badge><span className="font-medium">{e.title}</span></div>
                    <p className="mt-1 text-xs text-muted-foreground">{e.description}</p>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-5">
            <h3 className="mb-4 font-display text-xl font-semibold">Upcoming</h3>
            <div className="space-y-3">
              {upcoming.map(e => (
                <div key={e.id} className="rounded-lg border-l-4 p-3" style={{ borderColor: TYPE_COLOR[e.type] }}>
                  <div className="text-xs text-muted-foreground">{new Date(e.date).toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' })}</div>
                  <div className="font-medium">{e.title}</div>
                  <Badge variant="outline" className="mt-1 text-[10px]">{e.type}</Badge>
                </div>
              ))}
              {upcoming.length === 0 && <p className="text-sm text-muted-foreground">Nothing coming up.</p>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
