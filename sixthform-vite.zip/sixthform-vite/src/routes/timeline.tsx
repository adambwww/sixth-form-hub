import { createFileRoute } from '@tanstack/react-router';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';

export const Route = createFileRoute('/timeline')({
  component: Timeline,
});

const STEPS = [
  { when: 'September Y12', title: 'Induction', body: 'Meet your tutors, settle into subjects, find your common room seat.' },
  { when: 'October Y12', title: 'First assessments', body: 'Baseline tests across your subjects — a chance to find your level.' },
  { when: 'January Y12', title: 'Mock 1', body: 'First proper mock exams. Treat seriously to get useful feedback.' },
  { when: 'Spring Y12', title: 'University thinking', body: 'Open days, university research, taster days.' },
  { when: 'Summer Y12', title: 'Y12 exams', body: 'Internal exams that shape your predicted grades.' },
  { when: 'September Y13', title: 'UCAS opens', body: 'Personal statements, references, applications.' },
  { when: 'October Y13', title: 'Oxbridge & Medicine', body: 'Early deadlines — submit by 15 October.' },
  { when: 'January Y13', title: 'UCAS deadline', body: 'Final UCAS deadline for all undergraduate applications.' },
  { when: 'Spring Y13', title: 'Mocks & revision', body: 'The final mocks. Build your revision plan now.' },
  { when: 'May–June Y13', title: 'A-Levels', body: 'Exam season. Trust your preparation.' },
  { when: 'August Y13', title: 'Results Day', body: 'Pick up your results. Celebrate. Plan what\'s next.' },
];

function Timeline() {
  return (
    <div>
      <PageHero variant="split" eyebrow="Journey" title="Your two-year story." subtitle="From induction to results day — every milestone, mapped." />
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <ol className="relative space-y-6 border-l-2 border-burgundy/30 pl-8">
          {STEPS.map((s, i) => (
            <li key={i} className="relative">
              <span className="absolute -left-[42px] top-1.5 grid h-7 w-7 place-items-center rounded-full bg-gradient-burgundy text-xs font-bold text-white">{i+1}</span>
              <Card className="p-5">
                <div className="text-xs font-semibold uppercase tracking-wide text-gold-dark">{s.when}</div>
                <h3 className="mt-1 font-display text-lg font-semibold">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
              </Card>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
