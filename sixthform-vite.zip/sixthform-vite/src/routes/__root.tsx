import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
} from "@tanstack/react-router";
import { useEffect } from "react";

import { AuthProvider } from "@/context/AuthContext";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import { ScrollProgress } from "@/components/ScrollProgress";
import { BackToTop } from "@/components/BackToTop";
import { AnnouncementTicker } from "@/components/AnnouncementTicker";
import { Toaster } from "@/components/ui/sonner";
import { seedIfEmpty } from "@/lib/data";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-display font-bold text-gradient">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">The page you're looking for doesn't exist.</p>
        <Link to="/" className="mt-6 inline-flex items-center justify-center rounded-md bg-gradient-burgundy px-4 py-2 text-sm font-medium text-white">Go home</Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Something went wrong. Try refreshing or head back home.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="rounded-md bg-gradient-burgundy px-4 py-2 text-sm font-medium text-white">Try again</button>
          <a href="/" className="rounded-md border border-input bg-background px-4 py-2 text-sm font-medium">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

const STANDALONE = ['/login', '/admin'];

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const pathname = useRouterState({ select: s => s.location.pathname });
  const standalone = STANDALONE.some(p => pathname === p || pathname.startsWith(p + '/'));

  useEffect(() => { seedIfEmpty(); }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        {standalone ? (
          <Outlet />
        ) : (
          <>
            <ScrollProgress />
            <SiteNav />
            <AnnouncementTicker />
            <main className="min-h-[60vh]"><Outlet /></main>
            <SiteFooter />
            <BackToTop />
          </>
        )}
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}
