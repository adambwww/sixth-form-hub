import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Printer } from 'lucide-react';
import { getSdpSessions, type SdpSession } from '@/lib/data';

export const Route = createFileRoute('/sdp-timetables')({
  component: SDP,
});

const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday'] as const;
const TYPE_STYLES: Record<string, string> = {
  'Assembly': 'bg-burgundy-soft border-burgundy text-burgundy',
  'Workshop': 'bg-gold-soft border-gold text-gold-dark',
  'Mentor': 'bg-navy-soft border-navy text-navy',
  'External Speaker': 'bg-green-50 border-green-600 text-green-700 dark:bg-green-950',
  'Independent Study': 'bg-muted border-muted-foreground/30 text-foreground',
};

function SDP() {
  const [year, setYear] = useState<'Year 12' | 'Year 13' | 'Both'>('Both');
  const [view, setView] = useState<'week' | 'full'>('week');
  const [sessions, setSessions] = useState<SdpSession[]>([]);
  useEffect(() => { setSessions(getSdpSessions(year)); }, [year]);

  return (
    <div>
      <PageHero variant="navy" eyebrow="SDP" title="Your Skills Development Programme." subtitle="Assemblies, workshops, mentor sessions and external speakers — all in one timetable." />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex gap-2">
            {(['Year 12','Year 13','Both'] as const).map(y => (
              <button key={y} onClick={() => setYear(y)} className={`rounded-full px-4 py-1.5 text-sm font-medium ${year === y ? 'bg-burgundy text-white' : 'bg-muted hover:bg-burgundy-soft'}`}>{y}</button>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={() => setView('week')} className={`rounded-md px-3 py-1.5 text-sm ${view==='week'?'bg-foreground text-background':'bg-muted'}`}>Week View</button>
            <button onClick={() => setView('full')} className={`rounded-md px-3 py-1.5 text-sm ${view==='full'?'bg-foreground text-background':'bg-muted'}`}>Full Timetable</button>
            <Button variant="outline" size="sm" onClick={() => window.print()}><Printer className="mr-1 h-4 w-4" /> Print</Button>
          </div>
        </div>

        {view === 'week' ? (
          <div className="grid gap-3 lg:grid-cols-5">
            {DAYS.map(d => (
              <div key={d}>
                <h3 className="mb-2 font-display text-lg font-semibold">{d}</h3>
                <div className="space-y-2">
                  {sessions.filter(s => s.day === d).map(s => (
                    <Card key={s.id} className={`border-l-4 p-3 ${TYPE_STYLES[s.type]}`}>
                      <div className="text-xs font-semibold">{s.time}</div>
                      <div className="mt-1 text-sm font-bold text-foreground">{s.name}</div>
                      <div className="text-xs text-muted-foreground">{s.room} · {s.teacher}</div>
                      <p className="mt-1 text-xs">{s.topic}</p>
                      <Badge variant="outline" className="mt-2 text-[10px]">{s.yearGroup}</Badge>
                    </Card>
                  ))}
                  {sessions.filter(s => s.day === d).length === 0 && <p className="text-xs text-muted-foreground">—</p>}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Card className="overflow-x-auto p-0">
            <table className="w-full text-sm">
              <thead className="bg-muted text-xs uppercase tracking-wide">
                <tr><th className="p-3 text-left">Day</th><th className="p-3 text-left">Time</th><th className="p-3 text-left">Session</th><th className="p-3 text-left">Type</th><th className="p-3 text-left">Room</th><th className="p-3 text-left">Teacher</th><th className="p-3 text-left">Year</th></tr>
              </thead>
              <tbody>
                {sessions.map(s => (
                  <tr key={s.id} className="border-t">
                    <td className="p-3">{s.day}</td><td className="p-3">{s.time}</td>
                    <td className="p-3 font-medium">{s.name}<div className="text-xs text-muted-foreground">{s.topic}</div></td>
                    <td className="p-3"><Badge variant="outline">{s.type}</Badge></td>
                    <td className="p-3">{s.room}</td><td className="p-3">{s.teacher}</td><td className="p-3">{s.yearGroup}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        )}
      </div>
    </div>
  );
}
