import { createFileRoute, Link } from '@tanstack/react-router';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useEffect, useState } from 'react';
import { getSettings, type AdminSettings } from '@/lib/data';
import { ExternalLink, BookOpen, Mail, Calendar, Award } from 'lucide-react';

export const Route = createFileRoute('/student-space')({
  component: StudentSpace,
});

function StudentSpace() {
  const [settings, setSettings] = useState<AdminSettings | null>(null);
  useEffect(() => { setSettings(getSettings()); }, []);

  return (
    <div>
      <PageHero eyebrow="Student Space" title="Welcome to your space." subtitle="Everything curated just for you — this month's stories, values, and the people we celebrate." />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        {settings?.currentIssueTitle && (
          <Card className="mb-10 overflow-hidden bg-gradient-burgundy p-8 text-white shadow-lift">
            <div className="text-xs font-semibold uppercase tracking-wide text-white/70">Featured Issue</div>
            <h2 className="mt-2 font-display text-3xl font-bold">{settings.currentIssueTitle}</h2>
            <p className="mt-3 max-w-2xl text-white/80">{settings.currentIssueIntro}</p>
            {settings.currentIssueUrl && (
              <Button className="mt-5 bg-gradient-gold text-white hover:opacity-90" onClick={() => window.open(settings.currentIssueUrl, '_blank')}>
                Open PDF <ExternalLink className="ml-1.5 h-4 w-4" />
              </Button>
            )}
          </Card>
        )}

        <div className="grid gap-6 md:grid-cols-3">
          {settings?.valueOfMonth && <SpotlightCard label="Value of the month" body={settings.valueOfMonth} icon={Award} />}
          {settings?.studentOfMonth && <SpotlightCard label="Student of the month" body={settings.studentOfMonth} icon={Award} />}
          {settings?.teacherOfMonth && <SpotlightCard label="Teacher of the month" body={settings.teacherOfMonth} icon={Award} />}
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-3">
          <Link to="/weekly-emails"><Card className="hover-lift p-6"><Mail className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-semibold">Weekly Emails</h3><p className="text-sm text-muted-foreground">Catch up on every message.</p></Card></Link>
          <Link to="/resources"><Card className="hover-lift p-6"><BookOpen className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-semibold">Resources</h3><p className="text-sm text-muted-foreground">Notes, past papers, websites.</p></Card></Link>
          <Link to="/academic-calendar"><Card className="hover-lift p-6"><Calendar className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-semibold">Calendar</h3><p className="text-sm text-muted-foreground">Key dates and deadlines.</p></Card></Link>
        </div>
      </div>
    </div>
  );
}

function SpotlightCard({ label, body, icon: Icon }: { label: string; body: string; icon: any }) {
  return (
    <Card className="p-6">
      <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-gold-dark">
        <Icon className="h-4 w-4" /> {label}
      </div>
      <p className="text-sm leading-relaxed">{body}</p>
    </Card>
  );
}
