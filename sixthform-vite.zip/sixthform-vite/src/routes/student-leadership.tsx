import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { getLeadershipMembers, getPrefects, getSettings, type LeadershipMember, type Prefect } from '@/lib/data';

export const Route = createFileRoute('/student-leadership')({
  component: Leadership,
});

function Leadership() {
  const [members, setMembers] = useState<LeadershipMember[]>([]);
  const [prefects, setPrefects] = useState<Prefect[]>([]);
  const [email, setEmail] = useState('');
  useEffect(() => {
    setMembers(getLeadershipMembers());
    setPrefects(getPrefects());
    setEmail(getSettings().contactEmail);
  }, []);

  return (
    <div>
      <PageHero variant="split" eyebrow="Leadership" title="Your student voice." subtitle="Meet the team representing you, building bridges, and making Sixth Form what it should be." />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {members.map((m, i) => (
            <div key={m.id}>
              <Card className={`hover-lift relative p-6 text-center ${m.isHeadRole ? 'border-2 border-gold shadow-glow' : ''}`}>
                <div className="mx-auto mb-3 grid h-20 w-20 place-items-center rounded-full bg-gradient-burgundy font-display text-2xl font-bold text-white">
                  {m.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                </div>
                <div className="text-xs font-semibold uppercase tracking-wide text-burgundy">{m.role}</div>
                <h3 className="mt-1 font-display text-lg font-semibold">{m.name}</h3>
                <p className="mt-2 text-sm italic text-muted-foreground">{m.bio}</p>
              </Card>
            </div>
          ))}
        </div>

        <Accordion type="single" collapsible className="mt-12">
          <AccordionItem value="prefects">
            <AccordionTrigger className="font-display text-2xl">Prefect Team ({prefects.length})</AccordionTrigger>
            <AccordionContent>
              <div className="flex flex-wrap gap-2 pt-2">
                {prefects.map((p, i) => (
                  <Badge key={p.id} variant="outline" className={i % 2 === 0 ? 'bg-burgundy-soft text-burgundy' : 'bg-gold-soft text-gold-dark'}>
                    {p.name} · {p.year}
                  </Badge>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="mt-12 grid gap-5 sm:grid-cols-3">
          <Card className="p-6"><h3 className="mb-2 font-display text-xl font-semibold">What Leaders Do</h3><p className="text-sm text-muted-foreground">Represent every voice, organise events, and champion student wellbeing across the school.</p></Card>
          <Card className="p-6"><h3 className="mb-2 font-display text-xl font-semibold">How to Get Involved</h3><p className="text-sm text-muted-foreground">Speak to your form tutor, join a society, or apply when nominations open at the start of Year 13.</p></Card>
          <Card className="p-6"><h3 className="mb-2 font-display text-xl font-semibold">Contact the Team</h3><a href={`mailto:${email}`} className="text-sm font-medium text-burgundy hover:underline">{email}</a></Card>
        </div>
      </div>
    </div>
  );
}
