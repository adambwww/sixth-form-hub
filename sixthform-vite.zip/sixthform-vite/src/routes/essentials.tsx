import { createFileRoute, Link } from '@tanstack/react-router';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { ShieldAlert, Phone, MapPin, BookCheck } from 'lucide-react';

export const Route = createFileRoute('/essentials')({
  component: Essentials,
});

function Essentials() {
  return (
    <div>
      <PageHero eyebrow="Essentials" title="The basics, sorted." subtitle="Expectations, safeguarding, key contacts and everything you need on hand." />
      <div className="mx-auto grid max-w-6xl gap-5 px-4 py-12 sm:px-6 md:grid-cols-2">
        <Card className="p-6"><BookCheck className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Expectations</h3><p className="mt-2 text-sm text-muted-foreground">Be on time. Attend every lesson. Bring your best every day. Sixth Form is a privilege — own it.</p></Card>
        <Card className="p-6"><ShieldAlert className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Safeguarding</h3><p className="mt-2 text-sm text-muted-foreground">If something isn't right, talk to a trusted adult or our DSL. You will always be listened to.</p></Card>
        <Card className="p-6"><Phone className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Key contacts</h3><p className="mt-2 text-sm text-muted-foreground">Head of Sixth Form · Deputy Head · Form Tutor · Pastoral Lead. Reach all of them via the main office.</p></Card>
        <Card className="p-6"><MapPin className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Spaces</h3><p className="mt-2 text-sm text-muted-foreground">Common room, silent study, group rooms — see <Link to="/sdp-timetables" className="text-burgundy underline">SDP page</Link> for bookings.</p></Card>
      </div>
    </div>
  );
}
