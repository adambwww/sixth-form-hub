import { createFileRoute } from '@tanstack/react-router';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';

export const Route = createFileRoute('/opportunities')({
  component: Opportunities,
});

const OPPS = [
  { title: 'Cambridge Engineering Masterclass', tag: 'STEM', body: 'Free online masterclass series — Saturdays in November.', url: 'https://www.eng.cam.ac.uk' },
  { title: 'Imperial Summer School', tag: 'Summer', body: 'Two-week residential exploring engineering, medicine, business.', url: 'https://imperial.ac.uk' },
  { title: 'Sutton Trust Summer Schools', tag: 'University', body: 'Funded residential programmes for state-school students.', url: 'https://suttontrust.com' },
  { title: 'NCS — National Citizen Service', tag: 'Community', body: '4-week programme building leadership and social action skills.', url: 'https://ncsyes.co.uk' },
  { title: 'BBSRC Lab Internships', tag: 'Research', body: 'Paid summer internships in UK biotech and life-science labs.', url: 'https://bbsrc.ukri.org' },
  { title: 'UN Women UK Delegate', tag: 'Global', body: 'Apply to represent the UK at international youth conferences.', url: 'https://unwomenuk.org' },
];

function Opportunities() {
  return (
    <div>
      <PageHero variant="gold" eyebrow="Opportunities" title="Go beyond the classroom." subtitle="Competitions, summer schools, research and enrichment — all the chances to do something extraordinary." />
      <div className="mx-auto grid max-w-7xl gap-5 px-4 py-12 sm:px-6 md:grid-cols-2 lg:grid-cols-3">
        {OPPS.map((o, i) => (
          <Card key={i} className="hover-lift p-6">
            <Badge variant="outline" className="bg-burgundy-soft text-burgundy">{o.tag}</Badge>
            <h3 className="mt-3 font-display text-lg font-semibold">{o.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{o.body}</p>
            <Button size="sm" variant="outline" className="mt-4" onClick={() => window.open(o.url, '_blank')}>Find out more <ExternalLink className="ml-1 h-3 w-3" /></Button>
          </Card>
        ))}
      </div>
    </div>
  );
}
