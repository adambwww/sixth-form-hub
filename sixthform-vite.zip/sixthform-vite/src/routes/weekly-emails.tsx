import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ChevronDown, Search, Printer } from 'lucide-react';
import { getEmails, type WeeklyEmail } from '@/lib/data';

export const Route = createFileRoute('/weekly-emails')({
  component: Emails,
});

function termOf(date: string): 'Autumn' | 'Spring' | 'Summer' {
  const m = new Date(date).getMonth();
  if (m >= 8 || m === 11) return 'Autumn';
  if (m <= 2) return 'Spring';
  return 'Summer';
}

function Emails() {
  const [items, setItems] = useState<WeeklyEmail[]>([]);
  const [q, setQ] = useState('');
  const [term, setTerm] = useState<'All' | 'Autumn' | 'Spring' | 'Summer'>('All');
  const [open, setOpen] = useState<Record<string, boolean>>({});
  useEffect(() => { setItems(getEmails()); }, []);

  const filtered = items
    .filter(e => term === 'All' || termOf(e.dateSent) === term)
    .filter(e => !q || (e.subject + ' ' + e.body).toLowerCase().includes(q.toLowerCase()));

  const printEmail = (e: WeeklyEmail) => {
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`<html><head><title>${e.subject}</title><style>body{font-family:Georgia,serif;max-width:680px;margin:40px auto;padding:0 20px;color:#222}h1{font-family:Georgia,serif}pre{white-space:pre-wrap;font-family:inherit}</style></head><body><div style="color:#888;font-size:13px">${e.weekNumber} · ${new Date(e.dateSent).toLocaleDateString('en-GB')}</div><h1>${e.subject}</h1><pre>${e.body.replace(/[<>]/g, '')}</pre></body></html>`);
    w.document.close();
    setTimeout(() => w.print(), 200);
  };

  return (
    <div>
      <PageHero eyebrow="Weekly Emails" title="Never miss a thing." subtitle="Every email, archived. Search, filter, expand, and download as PDF." />
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <div className="mb-4 flex flex-wrap gap-2">
          {(['All','Autumn','Spring','Summer'] as const).map(t => (
            <button key={t} onClick={() => setTerm(t)} className={`rounded-full px-4 py-1.5 text-sm font-medium ${term === t ? 'bg-burgundy text-white' : 'bg-muted hover:bg-burgundy-soft'}`}>{t}</button>
          ))}
        </div>
        <div className="relative mb-6">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search subject or body…" className="pl-9" />
        </div>

        <div className="space-y-4">
          {filtered.map((e, i) => (
            <Card key={e.id} className="overflow-hidden p-6">
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <Badge variant="outline" className="bg-burgundy-soft text-burgundy">{e.weekNumber}</Badge>
                <span>{new Date(e.dateSent).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</span>
                {i === 0 && <Badge className="bg-gradient-gold text-white">Latest</Badge>}
              </div>
              <h3 className="mt-2 font-display text-2xl font-semibold">{e.subject}</h3>
              <p className="mt-2 line-clamp-2 text-muted-foreground">{e.body.slice(0, 200)}…</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {e.tags.map(t => <Badge key={t} variant="outline">{t}</Badge>)}
              </div>
              <div className="mt-4 flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setOpen(s => ({ ...s, [e.id]: !s[e.id] }))}>
                  <ChevronDown className={`mr-1 h-4 w-4 transition-transform ${open[e.id] ? 'rotate-180' : ''}`} /> Read in full
                </Button>
                <Button size="sm" variant="outline" onClick={() => printEmail(e)}><Printer className="mr-1 h-4 w-4" /> Download PDF</Button>
              </div>
              {open[e.id] && (
                <div className="mt-5 whitespace-pre-wrap rounded-lg border bg-muted/30 p-5 text-sm leading-relaxed">{e.body}</div>
              )}
            </Card>
          ))}
          {filtered.length === 0 && <p className="py-16 text-center text-muted-foreground">No emails match your filters.</p>}
        </div>
      </div>
    </div>
  );
}
