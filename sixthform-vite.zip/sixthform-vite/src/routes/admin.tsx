import { createFileRoute, useNavigate, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { LogOut, Shield, Plus, Pencil, Trash2, Bell, Mail, BookOpen, Target, CalendarClock, Calendar as CalendarIcon, Users, Settings as SettingsIcon, FileText, Home, KeyRound, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  getAllAnnouncements, addAnnouncement, updateAnnouncement, deleteAnnouncement,
  getAllEmails, addEmail, updateEmail, deleteEmail,
  getAllResources, addResource, updateResource, deleteResource,
  getSkillCategories, addSkillCategory, deleteSkillCategory,
  getSkillItems, addSkillItem, updateSkillItem, deleteSkillItem, setSkillOfWeek,
  getAllSdpSessions, addSdpSession, updateSdpSession, deleteSdpSession,
  getCalendarEvents, addCalendarEvent, updateCalendarEvent, deleteCalendarEvent,
  getLeadershipMembers, addLeadershipMember, updateLeadershipMember, deleteLeadershipMember,
  getPrefects, addPrefect, deletePrefect,
  getSettings, saveSettings,
  getAccounts, addAccount, updateAccount, deleteAccount,
  type Announcement, type WeeklyEmail, type Resource, type SkillItem, type SdpSession, type CalendarEvent, type LeadershipMember, type AdminSettings, type Account,
} from '@/lib/data';

export const Route = createFileRoute('/admin')({
  component: AdminPage,
});

type Tab = 'overview' | 'announcements' | 'emails' | 'resources' | 'skills' | 'sdp' | 'calendar' | 'leadership' | 'accounts' | 'settings';

function AdminPage() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [tab, setTab] = useState<Tab>('overview');
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => {
      if (!user || user.role !== 'admin') navigate({ to: '/login' });
      else setChecked(true);
    }, 100);
    return () => clearTimeout(t);
  }, [user, navigate]);

  if (!checked) return <div className="grid min-h-screen place-items-center text-muted-foreground">Checking access…</div>;

  const items: { id: Tab; label: string; icon: any }[] = [
    { id: 'overview', label: 'Overview', icon: Home },
    { id: 'announcements', label: 'Latest Updates', icon: Bell },
    { id: 'emails', label: 'Weekly Emails', icon: Mail },
    { id: 'resources', label: 'Resources', icon: BookOpen },
    { id: 'skills', label: 'Skill Checks', icon: Target },
    { id: 'sdp', label: 'SDP Timetables', icon: CalendarClock },
    { id: 'calendar', label: 'Academic Calendar', icon: CalendarIcon },
    { id: 'leadership', label: 'Student Leadership', icon: Users },
    { id: 'accounts', label: 'Accounts', icon: KeyRound },
    { id: 'settings', label: 'Monthly & Settings', icon: SettingsIcon },
  ];

  return (
    <div className="flex min-h-screen bg-muted/30">
      <aside className="admin-sidebar hidden w-60 shrink-0 flex-col border-r bg-card p-4 md:flex">
        <Link to="/" className="mb-1 flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-burgundy font-display font-bold text-white">SF</div>
          <span className="font-display text-sm font-bold">Admin Panel</span>
        </Link>
        <div className="mt-3 rounded-lg border bg-muted/40 p-2 text-xs">
          <div className="font-medium">{user?.displayName}</div>
          <Badge className="mt-1 bg-burgundy text-[10px] text-white"><Shield className="mr-1 h-3 w-3" />{user?.role}</Badge>
        </div>
        <nav className="mt-4 flex-1 space-y-0.5">
          {items.map(i => (
            <button key={i.id} onClick={() => setTab(i.id)} className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors ${tab === i.id ? 'bg-burgundy text-white' : 'hover:bg-muted'}`}>
              <i.icon className="h-4 w-4" /> {i.label}
            </button>
          ))}
        </nav>
        <button onClick={() => { logout(); navigate({ to: '/' }); }} className="mt-2 flex items-center gap-2 rounded-md px-3 py-2 text-sm text-destructive hover:bg-destructive/10">
          <LogOut className="h-4 w-4" /> Log out
        </button>
      </aside>

      <main className="flex-1 overflow-x-hidden p-4 sm:p-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 md:hidden">
          <Select value={tab} onValueChange={(v) => setTab(v as Tab)}>
            <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
            <SelectContent>{items.map(i => <SelectItem key={i.id} value={i.id}>{i.label}</SelectItem>)}</SelectContent>
          </Select>
          <Button size="sm" variant="ghost" onClick={() => { logout(); navigate({ to: '/' }); }}><LogOut className="mr-1 h-4 w-4" /></Button>
        </div>

        {tab === 'overview' && <Overview onJump={setTab} />}
        {tab === 'announcements' && <AnnouncementsAdmin />}
        {tab === 'emails' && <EmailsAdmin />}
        {tab === 'resources' && <ResourcesAdmin />}
        {tab === 'skills' && <SkillsAdmin />}
        {tab === 'sdp' && <SdpAdmin />}
        {tab === 'calendar' && <CalendarAdmin />}
        {tab === 'leadership' && <LeadershipAdmin />}
        {tab === 'accounts' && <AccountsAdmin />}
        {tab === 'settings' && <SettingsAdmin />}
      </main>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h1 className="mb-6 font-display text-3xl font-bold">{title}</h1>
      {children}
    </section>
  );
}

function ConfirmDelete({ onConfirm, label }: { onConfirm: () => void; label: string }) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild><Button size="icon" variant="ghost" className="text-destructive"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader><AlertDialogTitle>Delete {label}?</AlertDialogTitle><AlertDialogDescription>This cannot be undone.</AlertDialogDescription></AlertDialogHeader>
        <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={onConfirm} className="bg-destructive">Delete</AlertDialogAction></AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function Overview({ onJump }: { onJump: (t: Tab) => void }) {
  const [s, setS] = useState({ a: 0, r: 0, e: 0, sk: 0, c: 0, sdp: 0 });
  useEffect(() => {
    setS({ a: getAllAnnouncements().length, r: getAllResources().length, e: getAllEmails().length, sk: getSkillItems().length, c: getCalendarEvents().length, sdp: getAllSdpSessions().length });
  }, []);
  const stats = [
    { l: 'Announcements', v: s.a, t: 'announcements' as Tab },
    { l: 'Resources', v: s.r, t: 'resources' as Tab },
    { l: 'Weekly Emails', v: s.e, t: 'emails' as Tab },
    { l: 'Skill Items', v: s.sk, t: 'skills' as Tab },
    { l: 'Calendar Events', v: s.c, t: 'calendar' as Tab },
    { l: 'SDP Sessions', v: s.sdp, t: 'sdp' as Tab },
  ];
  return (
    <Section title="Overview">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map(x => (
          <Card key={x.l} className="cursor-pointer p-5 hover:shadow-lift" onClick={() => onJump(x.t)}>
            <div className="text-xs uppercase tracking-wide text-muted-foreground">{x.l}</div>
            <div className="mt-1 font-display text-4xl font-bold text-gradient">{x.v}</div>
          </Card>
        ))}
      </div>
      <div className="mt-8 flex flex-wrap gap-2">
        <Button onClick={() => onJump('announcements')}><Plus className="mr-1 h-4 w-4" /> New Announcement</Button>
        <Button variant="outline" onClick={() => onJump('resources')}><Plus className="mr-1 h-4 w-4" /> Upload Resource</Button>
        <Button variant="outline" onClick={() => onJump('emails')}><Plus className="mr-1 h-4 w-4" /> Post Weekly Email</Button>
        <Button variant="outline" onClick={() => onJump('calendar')}><Plus className="mr-1 h-4 w-4" /> Add Event</Button>
      </div>
    </Section>
  );
}

function AnnouncementsAdmin() {
  const [items, setItems] = useState<Announcement[]>([]);
  const [draft, setDraft] = useState<Partial<Announcement>>({ type: 'notice', pinned: false, published: true, tag: '' });
  const [editId, setEditId] = useState<string | null>(null);
  const refresh = () => setItems(getAllAnnouncements());
  useEffect(refresh, []);

  const save = () => {
    if (!draft.title || !draft.body) { toast.error('Title and body required'); return; }
    if (editId) updateAnnouncement(editId, draft);
    else addAnnouncement(draft as Omit<Announcement,'id'|'createdAt'|'order'>);
    setDraft({ type: 'notice', pinned: false, published: true, tag: '' }); setEditId(null);
    refresh(); toast.success(editId ? 'Updated' : 'Posted');
  };
  const quickWhatsApp = (text: string) => {
    if (!text.trim()) return;
    addAnnouncement({ title: text, body: text, type: 'whatsapp', tag: 'WhatsApp', pinned: false, published: true });
    refresh(); toast.success('Posted to feed');
  };
  const [wa, setWa] = useState('');

  return (
    <Section title="Latest Updates">
      <Card className="mb-6 p-5">
        <h3 className="mb-2 font-semibold">Quick WhatsApp notice</h3>
        <Textarea value={wa} onChange={e => setWa(e.target.value)} maxLength={280} placeholder="Type a quick notice…" />
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{wa.length}/280</span>
          <Button size="sm" onClick={() => { quickWhatsApp(wa); setWa(''); }}>Post to feed</Button>
        </div>
      </Card>

      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Announcement' : 'New Announcement'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Title"><Input value={draft.title || ''} onChange={e => setDraft({ ...draft, title: e.target.value })} /></Field>
          <Field label="Tag"><Input value={draft.tag || ''} onChange={e => setDraft({ ...draft, tag: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Body"><Textarea value={draft.body || ''} onChange={e => setDraft({ ...draft, body: e.target.value })} /></Field></div>
          <Field label="Type">
            <Select value={draft.type} onValueChange={v => setDraft({ ...draft, type: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="notice">Notice</SelectItem><SelectItem value="whatsapp">WhatsApp</SelectItem><SelectItem value="email-update">Email Update</SelectItem></SelectContent>
            </Select>
          </Field>
          <Field label="Link URL (optional)"><Input value={draft.linkUrl || ''} onChange={e => setDraft({ ...draft, linkUrl: e.target.value })} /></Field>
          <Field label="Link Label"><Input value={draft.linkLabel || ''} onChange={e => setDraft({ ...draft, linkLabel: e.target.value })} /></Field>
          <div className="flex items-center gap-6 pt-6">
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!draft.pinned} onCheckedChange={v => setDraft({ ...draft, pinned: v })} /> Pinned</label>
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!draft.published} onCheckedChange={v => setDraft({ ...draft, published: v })} /> Published</label>
          </div>
        </div>
        <div className="mt-4 flex gap-2">
          <Button onClick={save}>{editId ? 'Update' : 'Save'} Announcement</Button>
          {editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ type: 'notice', pinned: false, published: true, tag: '' }); }}>Cancel</Button>}
        </div>
      </Card>

      <div className="space-y-2">
        {items.map(a => (
          <Card key={a.id} className="flex items-start gap-3 p-4">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{a.title}</span>
                <Badge variant="outline">{a.type}</Badge>
                {a.pinned && <Badge className="bg-burgundy text-white">📌</Badge>}
                {!a.published && <Badge variant="outline">Draft</Badge>}
              </div>
              <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{a.body}</p>
            </div>
            <Button size="icon" variant="ghost" onClick={() => { setDraft(a); setEditId(a.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
            <ConfirmDelete label="announcement" onConfirm={() => { deleteAnnouncement(a.id); refresh(); }} />
          </Card>
        ))}
      </div>
    </Section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><Label className="mb-1.5 block text-xs">{label}</Label>{children}</div>;
}

function EmailsAdmin() {
  const [items, setItems] = useState<WeeklyEmail[]>([]);
  const [draft, setDraft] = useState<Partial<WeeklyEmail> & { tagsStr?: string }>({ published: true, dateSent: new Date().toISOString().slice(0,10), tagsStr: '' });
  const [editId, setEditId] = useState<string | null>(null);
  const refresh = () => setItems(getAllEmails());
  useEffect(refresh, []);
  const save = () => {
    if (!draft.subject || !draft.body || !draft.weekNumber) { toast.error('Week, subject and body required'); return; }
    const payload = { weekNumber: draft.weekNumber!, dateSent: draft.dateSent!, subject: draft.subject!, body: draft.body!, published: !!draft.published, tags: (draft.tagsStr || '').split(',').map(s => s.trim()).filter(Boolean) };
    if (editId) updateEmail(editId, payload);
    else addEmail(payload);
    setDraft({ published: true, dateSent: new Date().toISOString().slice(0,10), tagsStr: '' }); setEditId(null);
    refresh(); toast.success(editId ? 'Updated' : 'Saved');
  };
  return (
    <Section title="Weekly Emails">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Email' : 'Compose Email'}</h3>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Week"><Input placeholder="Week 7" value={draft.weekNumber || ''} onChange={e => setDraft({ ...draft, weekNumber: e.target.value })} /></Field>
          <Field label="Date sent"><Input type="date" value={draft.dateSent || ''} onChange={e => setDraft({ ...draft, dateSent: e.target.value })} /></Field>
          <Field label="Tags (comma-separated)"><Input value={draft.tagsStr || ''} onChange={e => setDraft({ ...draft, tagsStr: e.target.value })} /></Field>
          <div className="sm:col-span-3"><Field label="Subject"><Input value={draft.subject || ''} onChange={e => setDraft({ ...draft, subject: e.target.value })} /></Field></div>
          <div className="sm:col-span-3"><Field label="Body"><Textarea rows={8} value={draft.body || ''} onChange={e => setDraft({ ...draft, body: e.target.value })} /></Field></div>
        </div>
        <div className="mt-3 flex items-center gap-4">
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!draft.published} onCheckedChange={v => setDraft({ ...draft, published: v })} /> Published</label>
          <Button onClick={save}>{editId ? 'Update' : 'Save'}</Button>
          {editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ published: true, dateSent: new Date().toISOString().slice(0,10), tagsStr: '' }); }}>Cancel</Button>}
        </div>
      </Card>
      <div className="space-y-2">
        {items.map(e => (
          <Card key={e.id} className="flex items-center gap-3 p-4">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="bg-burgundy-soft text-burgundy">{e.weekNumber}</Badge>
                <span className="font-medium">{e.subject}</span>
                <Badge variant="outline">{e.published ? 'Published' : 'Draft'}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{e.dateSent}</p>
            </div>
            <Button size="icon" variant="ghost" onClick={() => { setDraft({ ...e, tagsStr: e.tags.join(', ') }); setEditId(e.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
            <ConfirmDelete label="email" onConfirm={() => { deleteEmail(e.id); refresh(); }} />
          </Card>
        ))}
      </div>
    </Section>
  );
}

const SUBJECTS = ['Mathematics','Physics','Chemistry','Biology','English Literature','History','Economics','Geography','Psychology','Computer Science','Further Maths','Art','Music','PE','UCAS','General'];

function ResourcesAdmin() {
  const [items, setItems] = useState<Resource[]>([]);
  const [draft, setDraft] = useState<Partial<Resource>>({ type: 'Notes', subject: 'General', featured: false, url: '' });
  const [mode, setMode] = useState<'url' | 'file'>('url');
  const [editId, setEditId] = useState<string | null>(null);
  const refresh = () => setItems(getAllResources());
  useEffect(refresh, []);
  const onFile = (f: File) => {
    if (f.size > 10 * 1024 * 1024) { toast.error('Max 10MB'); return; }
    const reader = new FileReader();
    reader.onload = () => setDraft(d => ({ ...d, url: reader.result as string, fileName: f.name, fileSize: `${(f.size/1024).toFixed(0)} KB` }));
    reader.readAsDataURL(f);
  };
  const save = () => {
    if (!draft.title || !draft.url) { toast.error('Title and URL/file required'); return; }
    if (editId) updateResource(editId, draft);
    else addResource(draft as Omit<Resource,'id'|'createdAt'>);
    setDraft({ type: 'Notes', subject: 'General', featured: false, url: '' }); setEditId(null);
    refresh(); toast.success(editId ? 'Updated' : 'Added');
  };
  return (
    <Section title="Resources">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Resource' : 'Add Resource'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Title"><Input value={draft.title || ''} onChange={e => setDraft({ ...draft, title: e.target.value })} /></Field>
          <Field label="Subject">
            <Select value={draft.subject} onValueChange={v => setDraft({ ...draft, subject: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{SUBJECTS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <div className="sm:col-span-2"><Field label="Description"><Textarea value={draft.description || ''} onChange={e => setDraft({ ...draft, description: e.target.value })} /></Field></div>
          <Field label="Type">
            <Select value={draft.type} onValueChange={v => setDraft({ ...draft, type: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{['Notes','Past Paper','Website','Video','Other'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <div className="flex items-center gap-6 pt-6">
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!draft.featured} onCheckedChange={v => setDraft({ ...draft, featured: v })} /> Featured</label>
          </div>
          <div className="sm:col-span-2">
            <div className="mb-2 flex gap-2 text-sm">
              <label><input type="radio" checked={mode==='url'} onChange={() => setMode('url')} className="mr-1" />Link (URL)</label>
              <label><input type="radio" checked={mode==='file'} onChange={() => setMode('file')} className="mr-1" />Upload file</label>
            </div>
            {mode === 'url' ? (
              <Input placeholder="https://…" value={draft.url || ''} onChange={e => setDraft({ ...draft, url: e.target.value, fileName: undefined })} />
            ) : (
              <Input type="file" onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f); }} />
            )}
            {draft.fileName && <p className="mt-1 text-xs text-muted-foreground">{draft.fileName} · {draft.fileSize}</p>}
          </div>
        </div>
        <div className="mt-4 flex gap-2"><Button onClick={save}>{editId ? 'Update' : 'Add'} Resource</Button>{editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ type: 'Notes', subject: 'General', featured: false, url: '' }); }}>Cancel</Button>}</div>
      </Card>
      <div className="space-y-2">
        {items.map(r => (
          <Card key={r.id} className="flex items-center gap-3 p-4">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium">{r.title}</span>
                <Badge variant="outline">{r.subject}</Badge>
                <Badge variant="outline">{r.type}</Badge>
                {r.featured && <Badge className="bg-gold text-white">★</Badge>}
              </div>
            </div>
            <Button size="icon" variant="ghost" onClick={() => window.open(r.url, '_blank')}><BookOpen className="h-4 w-4" /></Button>
            <Button size="icon" variant="ghost" onClick={() => { setDraft(r); setEditId(r.id); setMode(r.fileName ? 'file' : 'url'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
            <ConfirmDelete label="resource" onConfirm={() => { deleteResource(r.id); refresh(); }} />
          </Card>
        ))}
      </div>
    </Section>
  );
}

function SkillsAdmin() {
  const [cats, setCats] = useState(getSkillCategories());
  const [items, setItems] = useState(getSkillItems());
  const [draft, setDraft] = useState<Partial<SkillItem>>({ required: false, points: 10, isSkillOfWeek: false });
  const [editId, setEditId] = useState<string | null>(null);
  const [catName, setCatName] = useState('');
  const refresh = () => { setCats(getSkillCategories()); setItems(getSkillItems()); };
  useEffect(refresh, []);
  const sow = items.find(i => i.isSkillOfWeek);
  const save = () => {
    if (!draft.name || !draft.categoryId) { toast.error('Name & category required'); return; }
    if (editId) updateSkillItem(editId, draft);
    else addSkillItem(draft as Omit<SkillItem,'id'|'order'>);
    setDraft({ required: false, points: 10, isSkillOfWeek: false }); setEditId(null);
    refresh(); toast.success(editId ? 'Updated' : 'Added');
  };
  return (
    <Section title="Skill Checks">
      <Card className="mb-6 p-5">
        <div className="text-xs uppercase text-gold-dark">Skill of the Week</div>
        <div className="mt-1 font-display text-lg font-semibold">{sow ? sow.name : 'None set'}</div>
      </Card>
      <Card className="mb-6 p-5">
        <h3 className="mb-2 font-semibold">Add category</h3>
        <div className="flex gap-2"><Input value={catName} onChange={e => setCatName(e.target.value)} placeholder="Category name" /><Button onClick={() => { if (catName) { addSkillCategory(catName); setCatName(''); refresh(); } }}>Add</Button></div>
      </Card>
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Skill' : 'Add Skill'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Name"><Input value={draft.name || ''} onChange={e => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Category">
            <Select value={draft.categoryId} onValueChange={v => setDraft({ ...draft, categoryId: v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{cats.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <div className="sm:col-span-2"><Field label="Description"><Textarea value={draft.description || ''} onChange={e => setDraft({ ...draft, description: e.target.value })} /></Field></div>
          <Field label="Points"><Input type="number" value={draft.points ?? 10} onChange={e => setDraft({ ...draft, points: +e.target.value })} /></Field>
          <div className="flex items-center gap-2 pt-6"><Switch checked={!!draft.required} onCheckedChange={v => setDraft({ ...draft, required: v })} /> Required</div>
        </div>
        <div className="mt-3 flex gap-2"><Button onClick={save}>{editId ? 'Update' : 'Add'} Skill</Button>{editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ required: false, points: 10 }); }}>Cancel</Button>}</div>
      </Card>
      {cats.map(cat => (
        <div key={cat.id} className="mb-5">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold">{cat.name}</h3>
            <ConfirmDelete label="category" onConfirm={() => { deleteSkillCategory(cat.id); refresh(); }} />
          </div>
          <div className="space-y-2">
            {items.filter(i => i.categoryId === cat.id).map(s => (
              <Card key={s.id} className="flex items-center gap-2 p-3">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{s.name}</span>
                    {s.required && <Badge variant="outline">Required</Badge>}
                    <Badge variant="outline">{s.points} pts</Badge>
                    {s.isSkillOfWeek && <Badge className="bg-gold text-white">★ Week</Badge>}
                  </div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => { setSkillOfWeek(s.id); refresh(); toast.success('Set as Skill of the Week'); }}>★</Button>
                <Button size="icon" variant="ghost" onClick={() => { setDraft(s); setEditId(s.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
                <ConfirmDelete label="skill" onConfirm={() => { deleteSkillItem(s.id); refresh(); }} />
              </Card>
            ))}
          </div>
        </div>
      ))}
    </Section>
  );
}

function SdpAdmin() {
  const [items, setItems] = useState<SdpSession[]>([]);
  const [draft, setDraft] = useState<Partial<SdpSession>>({ day: 'Monday', type: 'Workshop', yearGroup: 'Both', repeat: 'Weekly', published: true });
  const [editId, setEditId] = useState<string | null>(null);
  const refresh = () => setItems(getAllSdpSessions());
  useEffect(refresh, []);
  const save = () => {
    if (!draft.name || !draft.time) { toast.error('Name & time required'); return; }
    if (editId) updateSdpSession(editId, draft);
    else addSdpSession(draft as Omit<SdpSession,'id'|'order'>);
    setDraft({ day: 'Monday', type: 'Workshop', yearGroup: 'Both', repeat: 'Weekly', published: true }); setEditId(null);
    refresh(); toast.success(editId ? 'Updated' : 'Added');
  };
  return (
    <Section title="SDP Timetables">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Session' : 'Add Session'}</h3>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Name"><Input value={draft.name || ''} onChange={e => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Day">
            <Select value={draft.day} onValueChange={v => setDraft({ ...draft, day: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{['Monday','Tuesday','Wednesday','Thursday','Friday'].map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Time"><Input placeholder="Period 1 (8:45–9:30)" value={draft.time || ''} onChange={e => setDraft({ ...draft, time: e.target.value })} /></Field>
          <Field label="Room"><Input value={draft.room || ''} onChange={e => setDraft({ ...draft, room: e.target.value })} /></Field>
          <Field label="Teacher"><Input value={draft.teacher || ''} onChange={e => setDraft({ ...draft, teacher: e.target.value })} /></Field>
          <Field label="Topic"><Input value={draft.topic || ''} onChange={e => setDraft({ ...draft, topic: e.target.value })} /></Field>
          <Field label="Type">
            <Select value={draft.type} onValueChange={v => setDraft({ ...draft, type: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{['Assembly','Workshop','Mentor','External Speaker','Independent Study'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Year">
            <Select value={draft.yearGroup} onValueChange={v => setDraft({ ...draft, yearGroup: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{['Year 12','Year 13','Both'].map(y => <SelectItem key={y} value={y}>{y}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Repeat">
            <Select value={draft.repeat} onValueChange={v => setDraft({ ...draft, repeat: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{['One-off','Weekly','Fortnightly'].map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
        </div>
        <div className="mt-3 flex items-center gap-3">
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!draft.published} onCheckedChange={v => setDraft({ ...draft, published: v })} /> Published</label>
          <Button onClick={save}>{editId ? 'Update' : 'Add'}</Button>
          {editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ day: 'Monday', type: 'Workshop', yearGroup: 'Both', repeat: 'Weekly', published: true }); }}>Cancel</Button>}
        </div>
      </Card>
      <div className="space-y-2">
        {items.map(s => (
          <Card key={s.id} className="flex items-center gap-2 p-4">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline">{s.day}</Badge>
                <span className="font-medium">{s.name}</span>
                <Badge variant="outline">{s.type}</Badge>
                <Badge variant="outline">{s.yearGroup}</Badge>
                {!s.published && <Badge variant="outline">Hidden</Badge>}
              </div>
              <div className="text-xs text-muted-foreground">{s.time} · {s.room}</div>
            </div>
            <Button size="icon" variant="ghost" onClick={() => { setDraft(s); setEditId(s.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
            <ConfirmDelete label="session" onConfirm={() => { deleteSdpSession(s.id); refresh(); }} />
          </Card>
        ))}
      </div>
    </Section>
  );
}

function CalendarAdmin() {
  const [items, setItems] = useState<CalendarEvent[]>([]);
  const [draft, setDraft] = useState<Partial<CalendarEvent>>({ type: 'Event' });
  const [editId, setEditId] = useState<string | null>(null);
  const refresh = () => setItems(getCalendarEvents());
  useEffect(refresh, []);
  const save = () => {
    if (!draft.title || !draft.date) { toast.error('Title & date required'); return; }
    if (editId) updateCalendarEvent(editId, draft);
    else addCalendarEvent(draft as Omit<CalendarEvent,'id'|'createdAt'>);
    setDraft({ type: 'Event' }); setEditId(null); refresh(); toast.success(editId ? 'Updated' : 'Added');
  };
  const importCsv = async (f: File) => {
    const Papa = (await import('papaparse')).default;
    Papa.parse<any>(f, { header: true, skipEmptyLines: true, complete: (r) => {
      r.data.forEach(row => {
        if (row.title && row.date) addCalendarEvent({ title: row.title, date: row.date, endDate: row.end_date || undefined, type: (row.type || 'Event') as any, description: row.description || '', link: row.link });
      });
      refresh(); toast.success(`Imported ${r.data.length} events`);
    }});
  };
  return (
    <Section title="Academic Calendar">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Event' : 'Add Event'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Title"><Input value={draft.title || ''} onChange={e => setDraft({ ...draft, title: e.target.value })} /></Field>
          <Field label="Date"><Input type="date" value={draft.date || ''} onChange={e => setDraft({ ...draft, date: e.target.value })} /></Field>
          <Field label="End date (optional)"><Input type="date" value={draft.endDate || ''} onChange={e => setDraft({ ...draft, endDate: e.target.value })} /></Field>
          <Field label="Type">
            <Select value={draft.type} onValueChange={v => setDraft({ ...draft, type: v as any })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{['Exam','UCAS','Event','Holiday','SDP','Other'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <div className="sm:col-span-2"><Field label="Description"><Textarea value={draft.description || ''} onChange={e => setDraft({ ...draft, description: e.target.value })} /></Field></div>
          <Field label="Link (optional)"><Input value={draft.link || ''} onChange={e => setDraft({ ...draft, link: e.target.value })} /></Field>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={save}>{editId ? 'Update' : 'Add'}</Button>
          {editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ type: 'Event' }); }}>Cancel</Button>}
          <label className="ml-auto inline-flex cursor-pointer items-center gap-2 rounded-md border bg-muted px-3 py-2 text-sm">
            <FileText className="h-4 w-4" /> Bulk import CSV
            <input type="file" accept=".csv" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) importCsv(f); }} />
          </label>
        </div>
      </Card>
      <div className="space-y-2">
        {items.map(e => (
          <Card key={e.id} className="flex items-center gap-2 p-4">
            <Badge variant="outline">{e.date}</Badge>
            <span className="flex-1 font-medium">{e.title}</span>
            <Badge variant="outline">{e.type}</Badge>
            <Button size="icon" variant="ghost" onClick={() => { setDraft(e); setEditId(e.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
            <ConfirmDelete label="event" onConfirm={() => { deleteCalendarEvent(e.id); refresh(); }} />
          </Card>
        ))}
      </div>
    </Section>
  );
}

function LeadershipAdmin() {
  const [members, setMembers] = useState<LeadershipMember[]>([]);
  const [prefects, setPrefects] = useState(getPrefects());
  const [draft, setDraft] = useState<Partial<LeadershipMember>>({ isHeadRole: false });
  const [editId, setEditId] = useState<string | null>(null);
  const [pName, setPName] = useState(''); const [pYear, setPYear] = useState<'Year 12' | 'Year 13'>('Year 12');
  const refresh = () => { setMembers(getLeadershipMembers()); setPrefects(getPrefects()); };
  useEffect(refresh, []);
  const save = () => {
    if (!draft.role || !draft.name) { toast.error('Role & name required'); return; }
    if (editId) updateLeadershipMember(editId, draft);
    else addLeadershipMember(draft as Omit<LeadershipMember,'id'|'order'>);
    setDraft({ isHeadRole: false }); setEditId(null); refresh(); toast.success(editId ? 'Updated' : 'Added');
  };
  return (
    <Section title="Student Leadership">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editId ? 'Edit Member' : 'Add Member'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Role"><Input value={draft.role || ''} onChange={e => setDraft({ ...draft, role: e.target.value })} /></Field>
          <Field label="Name"><Input value={draft.name || ''} onChange={e => setDraft({ ...draft, name: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Bio"><Textarea rows={2} value={draft.bio || ''} onChange={e => setDraft({ ...draft, bio: e.target.value })} /></Field></div>
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!draft.isHeadRole} onCheckedChange={v => setDraft({ ...draft, isHeadRole: v })} /> Head role</label>
        </div>
        <div className="mt-3 flex gap-2"><Button onClick={save}>{editId ? 'Update' : 'Add'}</Button>{editId && <Button variant="ghost" onClick={() => { setEditId(null); setDraft({ isHeadRole: false }); }}>Cancel</Button>}</div>
      </Card>
      <div className="mb-6 space-y-2">
        {members.map(m => (
          <Card key={m.id} className="flex items-center gap-2 p-3">
            <span className="flex-1"><span className="font-medium">{m.role}</span> · {m.name} {m.isHeadRole && <Badge className="ml-1 bg-gold text-white">Head</Badge>}</span>
            <Button size="icon" variant="ghost" onClick={() => { setDraft(m); setEditId(m.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}><Pencil className="h-4 w-4" /></Button>
            <ConfirmDelete label="member" onConfirm={() => { deleteLeadershipMember(m.id); refresh(); }} />
          </Card>
        ))}
      </div>

      <Card className="p-5">
        <h3 className="mb-3 font-semibold">Prefects</h3>
        <div className="flex flex-wrap gap-2">
          <Input className="max-w-xs" placeholder="Name" value={pName} onChange={e => setPName(e.target.value)} />
          <Select value={pYear} onValueChange={v => setPYear(v as any)}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="Year 12">Year 12</SelectItem><SelectItem value="Year 13">Year 13</SelectItem></SelectContent>
          </Select>
          <Button onClick={() => { if (pName) { addPrefect(pName, pYear); setPName(''); refresh(); } }}>Add Prefect</Button>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {prefects.map(p => (
            <Badge key={p.id} variant="outline" className="gap-2 py-1">
              {p.name} · {p.year}
              <button onClick={() => { deletePrefect(p.id); refresh(); }} className="text-destructive">×</button>
            </Badge>
          ))}
        </div>
      </Card>
    </Section>
  );
}

function SettingsAdmin() {
  const [s, setS] = useState<AdminSettings>(getSettings());
  useEffect(() => setS(getSettings()), []);
  const update = (patch: Partial<AdminSettings>) => setS(prev => ({ ...prev, ...patch }));
  const save = () => { saveSettings(s); toast.success('Settings saved'); };
  const onPdf = (f: File) => {
    const reader = new FileReader();
    reader.onload = () => update({ currentIssueUrl: reader.result as string });
    reader.readAsDataURL(f);
  };
  return (
    <Section title="Monthly Issue & Settings">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">Monthly Issue</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2"><Field label="Issue title"><Input value={s.currentIssueTitle} onChange={e => update({ currentIssueTitle: e.target.value })} /></Field></div>
          <div className="sm:col-span-2"><Field label="Intro"><Textarea value={s.currentIssueIntro} onChange={e => update({ currentIssueIntro: e.target.value })} /></Field></div>
          <Field label="PDF URL"><Input value={s.currentIssueUrl} onChange={e => update({ currentIssueUrl: e.target.value })} /></Field>
          <Field label="Or upload PDF"><Input type="file" accept="application/pdf" onChange={e => { const f = e.target.files?.[0]; if (f) onPdf(f); }} /></Field>
        </div>
        <div className="mt-3 flex gap-2">
          <Button onClick={save}>Save Issue</Button>
          {s.currentIssueUrl && <Button variant="outline" onClick={() => window.open(s.currentIssueUrl, '_blank')}>Open PDF ↗</Button>}
        </div>
      </Card>
      <Card className="p-5">
        <h3 className="mb-3 font-semibold">Portal Settings</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Portal title"><Input value={s.portalTitle} onChange={e => update({ portalTitle: e.target.value })} /></Field>
          <Field label="Contact email"><Input value={s.contactEmail} onChange={e => update({ contactEmail: e.target.value })} /></Field>
          <Field label="Academic year"><Input value={s.academicYear} onChange={e => update({ academicYear: e.target.value })} /></Field>
          <Field label="Student of the month"><Input value={s.studentOfMonth} onChange={e => update({ studentOfMonth: e.target.value })} /></Field>
          <Field label="Teacher of the month"><Input value={s.teacherOfMonth} onChange={e => update({ teacherOfMonth: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Value of the month"><Textarea value={s.valueOfMonth} onChange={e => update({ valueOfMonth: e.target.value })} /></Field></div>
        </div>
        <Button className="mt-3" onClick={save}>Save Settings</Button>
      </Card>
    </Section>
  );
}

function AccountsAdmin() {
  const { user: currentUser } = useAuth();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [editingUsername, setEditingUsername] = useState<string | null>(null);
  const [draft, setDraft] = useState<Account>({ username: '', password: '', role: 'admin', displayName: '' });
  const [showPw, setShowPw] = useState<Record<string, boolean>>({});

  const refresh = () => setAccounts(getAccounts());
  useEffect(() => { refresh(); }, []);

  const reset = () => { setEditingUsername(null); setDraft({ username: '', password: '', role: 'admin', displayName: '' }); };

  const submit = () => {
    if (!draft.username.trim() || !draft.password.trim() || !draft.displayName.trim()) {
      toast.error('Username, password, and display name are required'); return;
    }
    if (editingUsername) {
      const ok = updateAccount(editingUsername, draft);
      if (!ok) { toast.error('Username already exists'); return; }
      toast.success('Account updated');
    } else {
      const created = addAccount(draft);
      if (!created) { toast.error('Username already exists'); return; }
      toast.success('Account added');
    }
    refresh(); reset();
  };

  const startEdit = (a: Account) => { setDraft({ ...a }); setEditingUsername(a.username); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  const remove = (a: Account) => {
    if (currentUser?.username === a.username) { toast.error("You can't delete your own account"); return; }
    deleteAccount(a.username); refresh(); toast.success('Account deleted');
  };

  const admins = accounts.filter(a => a.role === 'admin');
  const leaders = accounts.filter(a => a.role === 'student-leader');

  const Row = ({ a }: { a: Account }) => (
    <Card className="flex flex-wrap items-center gap-2 p-3">
      <div className="min-w-0 flex-1">
        <div className="font-medium">{a.displayName} <Badge variant="outline" className="ml-1 text-[10px]">{a.role}</Badge></div>
        <div className="font-mono text-xs text-muted-foreground">{a.username} · {showPw[a.username] ? a.password : '••••••••'}</div>
      </div>
      <Button size="icon" variant="ghost" onClick={() => setShowPw(p => ({ ...p, [a.username]: !p[a.username] }))}>
        {showPw[a.username] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </Button>
      <Button size="icon" variant="ghost" onClick={() => startEdit(a)}><Pencil className="h-4 w-4" /></Button>
      <ConfirmDelete label={`account "${a.username}"`} onConfirm={() => remove(a)} />
    </Card>
  );

  return (
    <Section title="Accounts">
      <Card className="mb-6 p-5">
        <h3 className="mb-3 font-semibold">{editingUsername ? `Edit Account — ${editingUsername}` : 'Add Account'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Username"><Input value={draft.username} onChange={e => setDraft({ ...draft, username: e.target.value })} placeholder="e.g. newadmin" /></Field>
          <Field label="Display name"><Input value={draft.displayName} onChange={e => setDraft({ ...draft, displayName: e.target.value })} placeholder="e.g. Mr Smith" /></Field>
          <Field label="Password"><Input value={draft.password} onChange={e => setDraft({ ...draft, password: e.target.value })} placeholder="Set a strong password" /></Field>
          <Field label="Role">
            <Select value={draft.role} onValueChange={(v) => setDraft({ ...draft, role: v as Account['role'] })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="student-leader">Student Leader</SelectItem>
                <SelectItem value="student">Student</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </div>
        <div className="mt-3 flex gap-2">
          <Button onClick={submit}><Plus className="mr-1 h-4 w-4" />{editingUsername ? 'Update' : 'Add'}</Button>
          {editingUsername && <Button variant="ghost" onClick={reset}>Cancel</Button>}
        </div>
        <p className="mt-3 text-xs text-muted-foreground">Accounts are stored locally in this browser. For production, move auth to Lovable Cloud.</p>
      </Card>

      <h3 className="mb-2 font-display text-lg font-semibold">Admins</h3>
      <div className="mb-6 space-y-2">{admins.map(a => <Row key={a.username} a={a} />)}</div>
      <h3 className="mb-2 font-display text-lg font-semibold">Student Leaders</h3>
      <div className="space-y-2">{leaders.map(a => <Row key={a.username} a={a} />)}</div>
    </Section>
  );
}
