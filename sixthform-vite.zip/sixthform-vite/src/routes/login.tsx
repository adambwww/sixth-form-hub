import { createFileRoute, useNavigate, Link } from '@tanstack/react-router';
import { useState } from 'react';
import { motion } from 'motion/react';
import { Eye, EyeOff, ArrowLeft } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { login } from '@/lib/data';
import { useAuth } from '@/context/AuthContext';

export const Route = createFileRoute('/login')({
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);
  const [shaking, setShaking] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const u = login(username, password);
    if (!u) {
      setError(true); setShaking(true);
      setTimeout(() => setShaking(false), 500);
      return;
    }
    setUser(u);
    navigate({ to: u.role === 'admin' ? '/admin' : '/student-leadership' });
  };

  return (
    <div className="grid min-h-screen place-items-center bg-gradient-to-br from-burgundy-soft via-background to-gold-soft p-4">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-burgundy"><ArrowLeft className="h-4 w-4" /> Back to portal</Link>

        <motion.div animate={shaking ? { x: [0, -8, 8, -6, 6, 0] } : {}} transition={{ duration: 0.4 }}>
          <div className="rounded-2xl border bg-card p-8 shadow-lift">
            <div className="mx-auto mb-5 grid h-20 w-20 place-items-center rounded-2xl bg-gradient-burgundy font-display text-3xl font-bold text-white shadow-glow">SF</div>
            <h1 className="text-center font-display text-2xl font-bold">Sixth Form Hub</h1>
            <p className="mt-1 text-center text-sm text-muted-foreground">Staff & Student Leader Login</p>

            <form onSubmit={submit} className="mt-6 space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input id="username" autoComplete="username" value={username} onChange={e => { setUsername(e.target.value); setError(false); }} className="mt-1.5" required />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <div className="relative mt-1.5">
                  <Input id="password" type={show ? 'text' : 'password'} value={password} onChange={e => { setPassword(e.target.value); setError(false); }} required />
                  <button type="button" onClick={() => setShow(!show)} aria-label="Toggle password" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted-foreground hover:bg-muted">
                    {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              {error && <p className="text-sm font-medium text-destructive">Incorrect username or password.</p>}
              <Button type="submit" className="w-full bg-gradient-gold text-white hover:opacity-90">Sign in</Button>
            </form>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
