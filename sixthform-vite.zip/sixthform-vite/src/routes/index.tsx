import { createFileRoute, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { Sparkles, ArrowRight, BookOpen, Mail, Calendar, Users, Target, CalendarClock, Bell, MessageCircle, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { getAnnouncements, getCalendarEvents, getSkillOfWeek, getSkillCategories, toggleCompletion, getCompletions, timeAgo, type SkillItem, type Announcement, type CalendarEvent } from '@/lib/data';

export const Route = createFileRoute('/')({
  component: Home,
});

function Home() {
  return (
    <div>
      <Hero />
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-3">
        <CountdownWidget />
        <SkillOfWeekWidget />
        <StatsCard />
      </div>
      <LatestUpdates />
      <StatsBar />
      <QuickAccess />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-hero text-white">
      <div className="pointer-events-none absolute -left-24 -top-32 h-96 w-96 rounded-full bg-burgundy/40 blur-3xl animate-float-slow" />
      <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-gold/40 blur-3xl animate-float-fast" />
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32">
        <div>
          <Badge className="bg-white/15 text-white hover:bg-white/20">✦ Welcome back, Sixth Form</Badge>
          <h1 className="mt-6 max-w-3xl font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            Your home for <span className="bg-gradient-to-r from-gold to-white bg-clip-text text-transparent">everything Sixth Form.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-white/80">
            Announcements, weekly emails, the SDP timetable, your skill checks, UCAS dates and every resource you need — in one beautiful place.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link to="/student-space"><Button size="lg" className="bg-gradient-gold text-white hover:opacity-90">Get started <ArrowRight className="ml-1.5 h-4 w-4" /></Button></Link>
            <Link to="/timeline"><Button size="lg" variant="outline" className="glass border-white/30 text-white hover:bg-white/15 hover:text-white">My Journey →</Button></Link>
          </div>
        </div>
      </div>
    </section>
  );
}

function CountdownWidget() {
  const [event, setEvent] = useState<CalendarEvent | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const find = () => {
      const today = new Date(); today.setHours(0,0,0,0);
      const upcoming = getCalendarEvents()
        .filter(e => (e.type === 'UCAS' || e.type === 'Exam') && new Date(e.date) >= today)
        .sort((a,b) => a.date.localeCompare(b.date))[0];
      setEvent(upcoming || null);
    };
    find();
    const i = setInterval(() => setNow(Date.now()), 60_000);
    return () => clearInterval(i);
  }, []);

  if (!event) return null;
  const diff = new Date(event.date).getTime() - now;
  const days = Math.max(0, Math.floor(diff / 86_400_000));
  const hours = Math.max(0, Math.floor((diff % 86_400_000) / 3_600_000));
  const minutes = Math.max(0, Math.floor((diff % 3_600_000) / 60_000));

  return (
    <Card className="overflow-hidden border-burgundy/20 p-6">
      <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-burgundy">
        <CalendarClock className="h-4 w-4" /> Next key date
      </div>
      <h3 className="font-display text-xl font-semibold">{event.title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{new Date(event.date).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <Stat n={days} l="days" />
        <Stat n={hours} l="hrs" />
        <Stat n={minutes} l="min" />
      </div>
    </Card>
  );
}
function Stat({ n, l }: { n: number; l: string }) {
  return (
    <div className="rounded-lg bg-burgundy-soft py-3">
      <div className="font-display text-3xl font-bold text-burgundy">{n}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{l}</div>
    </div>
  );
}

function SkillOfWeekWidget() {
  const [skill, setSkill] = useState<SkillItem | null>(null);
  const [done, setDone] = useState(false);

  const refresh = () => {
    const s = getSkillOfWeek();
    setSkill(s);
    if (s) setDone(getCompletions('guest').some(c => c.skillId === s.id));
  };
  useEffect(refresh, []);
  if (!skill) return null;

  return (
    <Card className="relative overflow-hidden border-2 border-gold/40 bg-gold-soft p-6">
      <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-gold-dark">
        <Sparkles className="h-4 w-4" /> Skill of the Week
      </div>
      <h3 className="font-display text-xl font-semibold">{skill.name}</h3>
      <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{skill.description}</p>
      <div className="mt-4 flex gap-2">
        <Button size="sm" onClick={() => { toggleCompletion('guest', skill.id); refresh(); }} className={done ? 'bg-green-600 hover:bg-green-700' : 'bg-gradient-gold'}>
          {done ? '✓ Completed!' : 'Mark as done ✓'}
        </Button>
        <Link to="/skill-checks"><Button size="sm" variant="outline">View all</Button></Link>
      </div>
    </Card>
  );
}

function StatsCard() {
  return (
    <Card className="bg-gradient-burgundy p-6 text-white">
      <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-white/70">This Month</div>
      <h3 className="font-display text-xl font-semibold">October 2024</h3>
      <ul className="mt-4 space-y-2 text-sm">
        <li>★ Value: <span className="text-gold">Resilience</span></li>
        <li>★ Student spotlight: Aisha Mohammed</li>
        <li>★ Teacher spotlight: Dr Chen</li>
      </ul>
    </Card>
  );
}

const TYPE_ICONS = { 'notice': Bell, 'whatsapp': MessageCircle, 'email-update': Mail } as const;

function LatestUpdates() {
  const [items, setItems] = useState<Announcement[]>([]);
  const [tab, setTab] = useState<'all' | 'notice' | 'whatsapp' | 'email-update'>('all');
  useEffect(() => { setItems(getAnnouncements()); }, []);
  const filtered = tab === 'all' ? items : items.filter(i => i.type === tab);

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="mb-6 flex items-end justify-between">
        <div>
          <h2 className="font-display text-3xl font-bold">Latest updates</h2>
          <p className="text-sm text-muted-foreground">Everything happening, in one stream.</p>
        </div>
      </div>
      <Tabs value={tab} onValueChange={v => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="email-update">Emails</TabsTrigger>
          <TabsTrigger value="notice">Notices</TabsTrigger>
          <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="mt-6" aria-live="polite">
          <div className="grid gap-3 md:grid-cols-2">
            {filtered.map(item => {
              const Icon = TYPE_ICONS[item.type];
              const isNew = Date.now() - new Date(item.createdAt).getTime() < 86_400_000;
              return (
                <div key={item.id}>
                  <Card className="hover-lift p-5">
                    <div className="flex items-start gap-3">
                      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-burgundy-soft text-burgundy"><Icon className="h-4 w-4" /></div>
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-semibold leading-tight">{item.title}</h3>
                          <Badge variant="outline" className="text-[10px]">{item.tag}</Badge>
                          {isNew && <Badge className="bg-gradient-gold text-[10px] text-white">New</Badge>}
                          {item.pinned && <Badge className="bg-burgundy text-[10px] text-white">📌</Badge>}
                        </div>
                        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{item.body}</p>
                        <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                          <span>{timeAgo(item.createdAt)}</span>
                          {item.linkUrl && (
                            <a href={item.linkUrl} target="_blank" rel="noreferrer" className="font-medium text-burgundy hover:underline">
                              {item.linkLabel || 'Open'} →
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>
              );
            })}
            {filtered.length === 0 && <p className="col-span-full py-10 text-center text-sm text-muted-foreground">No updates here yet.</p>}
          </div>
        </TabsContent>
      </Tabs>
    </section>
  );
}

function StatsBar() {
  const stats = [
    { n: '120+', l: 'Active students' },
    { n: '50+', l: 'Resources & guides' },
    { n: '8', l: 'Leadership roles' },
    { n: '15', l: 'UCAS partner unis' },
  ];
  return (
    <section className="bg-gradient-navy py-14 text-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 text-center sm:grid-cols-4 sm:px-6">
        {stats.map(s => (
          <div key={s.l}>
            <div className="font-display text-4xl font-bold text-gold sm:text-5xl">{s.n}</div>
            <div className="mt-1 text-sm text-white/70">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function QuickAccess() {
  const cards = [
    { to: '/resources', label: 'Resources', icon: BookOpen },
    { to: '/weekly-emails', label: 'Weekly Emails', icon: Mail },
    { to: '/sdp-timetables', label: 'SDP Timetables', icon: CalendarClock },
    { to: '/academic-calendar', label: 'Calendar', icon: Calendar },
    { to: '/student-leadership', label: 'Leadership', icon: Users },
    { to: '/skill-checks', label: 'Skill Checks', icon: Target },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <h2 className="mb-8 font-display text-3xl font-bold">Quick access</h2>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {cards.map(c => (
          <Link key={c.to} to={c.to}>
            <Card className="hover-lift group flex aspect-square flex-col items-center justify-center gap-3 p-4 text-center">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-burgundy text-white transition-transform group-hover:scale-110">
                <c.icon className="h-5 w-5" />
              </div>
              <span className="text-sm font-medium">{c.label}</span>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  );
}
