import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useMemo, useState } from 'react';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Download, ExternalLink, Pin, Search, FileText, Globe, Video, FileQuestion } from 'lucide-react';
import { getAllResources, subjectColor, type Resource } from '@/lib/data';

export const Route = createFileRoute('/resources')({
  component: Resources,
});

const TYPE_ICONS: Record<string, any> = { 'Notes': FileText, 'Past Paper': FileQuestion, 'Website': Globe, 'Video': Video, 'Other': FileText };
const TYPES = ['All Types','Notes','Past Paper','Website','Video','Other'];

function Resources() {
  const [items, setItems] = useState<Resource[]>([]);
  const [subject, setSubject] = useState('All');
  const [type, setType] = useState('All Types');
  const [q, setQ] = useState('');
  useEffect(() => { setItems(getAllResources()); }, []);

  const subjects = useMemo(() => ['All', ...Array.from(new Set(items.map(i => i.subject)))], [items]);
  const filtered = items
    .filter(i => subject === 'All' || i.subject === subject)
    .filter(i => type === 'All Types' || i.type === type)
    .filter(i => !q || (i.title + ' ' + i.description).toLowerCase().includes(q.toLowerCase()))
    .sort((a,b) => (b.featured?1:0) - (a.featured?1:0));

  const download = (r: Resource) => {
    const a = document.createElement('a');
    a.href = r.url; a.download = r.fileName || 'resource';
    document.body.appendChild(a); a.click(); a.remove();
  };

  return (
    <div>
      <PageHero eyebrow="Resources" title="Everything you need, in one place." subtitle="Past papers, websites, notes and videos — filtered by subject, easy to find." />
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-center gap-2 overflow-x-auto pb-1">
          {subjects.map(s => (
            <button key={s} onClick={() => setSubject(s)} className={`shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${subject === s ? 'bg-burgundy text-white' : 'bg-muted hover:bg-burgundy-soft'}`}>{s}</button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {TYPES.map(t => (
            <button key={t} onClick={() => setType(t)} className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${type === t ? 'bg-gold text-white' : 'bg-muted hover:bg-gold-soft'}`}>{t}</button>
          ))}
        </div>
        <div className="relative mt-5 max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search resources…" className="pl-9" />
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map(r => {
            const Icon = TYPE_ICONS[r.type] || FileText;
            const isNew = Date.now() - new Date(r.createdAt).getTime() < 7 * 86_400_000;
            const isLink = /^https?:/.test(r.url);
            return (
              <div key={r.id}>
                <Card className="hover-lift relative h-full overflow-hidden p-5" style={{ borderLeft: `4px solid ${subjectColor(r.subject)}` }}>
                  <div className="flex items-start justify-between gap-2">
                    <Icon className="h-5 w-5 text-burgundy" />
                    <div className="flex gap-1">
                      {r.featured && <Pin className="h-4 w-4 fill-gold text-gold" />}
                      {isNew && <Badge className="bg-gradient-gold text-[10px] text-white">New</Badge>}
                    </div>
                  </div>
                  <h3 className="mt-3 font-semibold leading-tight">{r.title}</h3>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{r.description}</p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <Badge variant="outline" style={{ borderColor: subjectColor(r.subject), color: subjectColor(r.subject) }}>{r.subject}</Badge>
                    <Badge variant="outline">{r.type}</Badge>
                  </div>
                  <div className="mt-4">
                    {isLink ? (
                      <Button size="sm" onClick={() => window.open(r.url, '_blank')} className="bg-burgundy hover:bg-burgundy-dark">Open <ExternalLink className="ml-1 h-3 w-3" /></Button>
                    ) : (
                      <Button size="sm" onClick={() => download(r)} className="bg-burgundy hover:bg-burgundy-dark">Download <Download className="ml-1 h-3 w-3" /></Button>
                    )}
                  </div>
                </Card>
              </div>
            );
          })}
        </div>
        {filtered.length === 0 && <p className="py-16 text-center text-muted-foreground">No resources match your filters.</p>}
      </div>
    </div>
  );
}
