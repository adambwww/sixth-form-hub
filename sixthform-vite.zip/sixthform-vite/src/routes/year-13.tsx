import { createFileRoute, Link } from '@tanstack/react-router';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Target, GraduationCap, Mail, ClipboardCheck } from 'lucide-react';

export const Route = createFileRoute('/year-13')({
  component: Year13,
});

function Year13() {
  return (
    <div>
      <PageHero variant="navy" eyebrow="Year 13" title="The final push." subtitle="UCAS, mocks, your personal statement, exam season — and the future after that." />
      <div className="mx-auto grid max-w-6xl gap-5 px-4 py-12 sm:px-6 md:grid-cols-2">
        <Card className="p-6"><GraduationCap className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">UCAS</h3><p className="mt-2 text-sm text-muted-foreground">Drop-in clinics every Tuesday lunchtime in Room 204. See the <Link to="/academic-calendar" className="text-burgundy underline">calendar</Link> for deadlines.</p></Card>
        <Card className="p-6"><ClipboardCheck className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Mocks</h3><p className="mt-2 text-sm text-muted-foreground">Y13 mocks are your dress rehearsal. Treat them like the real thing.</p></Card>
        <Card className="p-6"><Target className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Final exams</h3><p className="mt-2 text-sm text-muted-foreground">A-Level exams begin in May. Plan your revision now, not in April.</p></Card>
        <Card className="p-6"><Mail className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Stay in the loop</h3><p className="mt-2 text-sm text-muted-foreground">Read every <Link to="/weekly-emails" className="text-burgundy underline">weekly email</Link> — they include things only Year 13 needs.</p></Card>
      </div>
    </div>
  );
}
