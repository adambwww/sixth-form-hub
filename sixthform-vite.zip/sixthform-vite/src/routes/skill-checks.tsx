import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useMemo, useState } from 'react';

import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Download, Sparkles } from 'lucide-react';
import { getSkillCategories, getSkillItems, getSkillOfWeek, toggleCompletion, getCompletions, updateEvidence, type SkillItem, type SkillCategory, type SkillCompletion } from '@/lib/data';
import { useAuth } from '@/context/AuthContext';

export const Route = createFileRoute('/skill-checks')({
  component: SkillChecks,
});

function SkillChecks() {
  const { user } = useAuth();
  const username = user?.username || 'guest';
  const [cats, setCats] = useState<SkillCategory[]>([]);
  const [items, setItems] = useState<SkillItem[]>([]);
  const [sow, setSow] = useState<SkillItem | null>(null);
  const [completions, setCompletions] = useState<SkillCompletion[]>([]);

  const refresh = () => {
    setCats(getSkillCategories());
    setItems(getSkillItems());
    setSow(getSkillOfWeek());
    setCompletions(getCompletions(username));
  };
  useEffect(refresh, [username]);

  const total = items.length;
  const completed = completions.length;
  const verified = completions.filter(c => c.verified).length;
  const pct = total > 0 ? completed / total : 0;

  const isDone = (id: string) => completions.some(c => c.skillId === id);
  const evidence = (id: string) => completions.find(c => c.skillId === id)?.evidence || '';
  const verifiedFor = (id: string) => completions.find(c => c.skillId === id)?.verified;

  const download = () => {
    const lines = ['My Skills Progress', '='.repeat(40), ''];
    cats.forEach(cat => {
      const catItems = items.filter(i => i.categoryId === cat.id && isDone(i.id));
      if (!catItems.length) return;
      lines.push(cat.name + ':');
      catItems.forEach(s => lines.push(`  ✓ ${s.name} (${s.points} pts)${verifiedFor(s.id) ? ' [verified]' : ''}`));
      lines.push('');
    });
    lines.push(`Total: ${completed}/${total} skills completed, ${verified} verified.`);
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'my-skills-progress.txt'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <PageHero eyebrow="Skill Checks" title="Build your skills, track your progress." subtitle="Every skill you complete is one step closer to your Sixth Form Skills Award." />
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        {sow && (
          <Card className="mb-8 border-2 border-gold bg-gold-soft p-6">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-gold-dark"><Sparkles className="h-4 w-4" /> Skill of the Week</div>
            <h2 className="mt-2 font-display text-2xl font-bold">{sow.name}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{sow.description}</p>
          </Card>
        )}

        <div className="mb-8 grid items-center gap-6 sm:grid-cols-[auto_1fr_auto]">
          <ProgressRing pct={pct} />
          <div>
            <h3 className="font-display text-xl font-semibold">Your progress</h3>
            <p className="text-sm text-muted-foreground">{completed} of {total} completed · {verified} verified</p>
          </div>
          <Button onClick={download} variant="outline"><Download className="mr-1.5 h-4 w-4" /> Download progress</Button>
        </div>

        <Accordion type="multiple" defaultValue={cats.map(c => c.id)} className="space-y-3">
          {cats.map(cat => {
            const catItems = items.filter(i => i.categoryId === cat.id);
            const catDone = catItems.filter(i => isDone(i.id)).length;
            return (
              <AccordionItem key={cat.id} value={cat.id} className="overflow-hidden rounded-xl border bg-card">
                <AccordionTrigger className="px-5 hover:no-underline">
                  <div className="flex items-center gap-3">
                    <span className="font-display text-lg font-semibold">{cat.name}</span>
                    <Badge variant="outline">{catDone}/{catItems.length}</Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-5">
                  <div className="space-y-3 pb-3">
                    {catItems.map(s => (
                      <div key={s.id} className="flex gap-3 rounded-lg border bg-background p-4">
                        <Checkbox checked={isDone(s.id)} onCheckedChange={() => { toggleCompletion(username, s.id); refresh(); }} className="mt-1" />
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-medium">{s.name}</span>
                            {s.required && <Badge variant="outline" className="bg-burgundy-soft text-burgundy">Required</Badge>}
                            <Badge variant="outline" className="bg-gold-soft text-gold-dark">{s.points} pts</Badge>
                            {verifiedFor(s.id) && <Badge className="bg-green-600 text-white">Verified ✓</Badge>}
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground">{s.description}</p>
                          {isDone(s.id) && (
                            <Input
                              placeholder="Add evidence (link, note…)"
                              defaultValue={evidence(s.id)}
                              onBlur={e => { updateEvidence(username, s.id, e.target.value); refresh(); }}
                              className="mt-2 text-sm"
                            />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      </div>
    </div>
  );
}

function ProgressRing({ pct }: { pct: number }) {
  const r = 50, c = 2 * Math.PI * r;
  const offset = c * (1 - pct);
  return (
    <svg width="120" height="120" viewBox="0 0 120 120">
      <circle cx="60" cy="60" r={r} stroke="hsl(var(--muted, 220 14% 96%))" strokeWidth="10" fill="none" className="opacity-30" />
      <circle cx="60" cy="60" r={r} stroke="url(#g)" strokeWidth="10" fill="none" strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        style={{ transition: 'stroke-dashoffset 1.2s ease-out' }}
        transform="rotate(-90 60 60)" />
      <defs>
        <linearGradient id="g" x1="0" x2="1">
          <stop offset="0%" stopColor="#9d3d3d" />
          <stop offset="100%" stopColor="#c99216" />
        </linearGradient>
      </defs>
      <text x="60" y="65" textAnchor="middle" className="fill-foreground font-display text-2xl font-bold">{Math.round(pct * 100)}%</text>
    </svg>
  );
}
