import { createFileRoute, Link } from '@tanstack/react-router';
import { PageHero } from '@/components/PageHero';
import { Card } from '@/components/ui/card';
import { Sparkles, BookOpen, Users, Compass } from 'lucide-react';

export const Route = createFileRoute('/year-12')({
  component: Year12,
});

function Year12() {
  return (
    <div>
      <PageHero eyebrow="Year 12" title="Your launchpad." subtitle="Settle in, find your rhythm, and start building the foundation of your A-Level grades." />
      <div className="mx-auto grid max-w-6xl gap-5 px-4 py-12 sm:px-6 md:grid-cols-2">
        <Card className="p-6"><Sparkles className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">First weeks</h3><p className="mt-2 text-sm text-muted-foreground">Get to know your tutors, build your timetable, and dive into your three (or four) subjects.</p></Card>
        <Card className="p-6"><BookOpen className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Study habits</h3><p className="mt-2 text-sm text-muted-foreground">Year 12 is the time to lock in active revision, weekly planning, and asking for help early.</p></Card>
        <Card className="p-6"><Users className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Enrichment</h3><p className="mt-2 text-sm text-muted-foreground">Join a society, lead a project, or volunteer — see <Link to="/opportunities" className="text-burgundy underline">Opportunities</Link>.</p></Card>
        <Card className="p-6"><Compass className="mb-2 h-6 w-6 text-burgundy" /><h3 className="font-display text-xl font-semibold">Looking ahead</h3><p className="mt-2 text-sm text-muted-foreground">Begin thinking about university, apprenticeships, and personal statements before Year 13.</p></Card>
      </div>
    </div>
  );
}
