// Sixth Form Hub — Data Layer (localStorage-backed)

export interface User {
  username: string;
  role: 'admin' | 'student-leader' | 'student';
  displayName: string;
}

export interface Announcement {
  id: string;
  title: string;
  body: string;
  tag: string;
  linkUrl?: string;
  linkLabel?: string;
  type: 'notice' | 'whatsapp' | 'email-update';
  pinned: boolean;
  published: boolean;
  createdAt: string;
  order: number;
}

export interface WeeklyEmail {
  id: string;
  weekNumber: string;
  dateSent: string;
  subject: string;
  body: string;
  tags: string[];
  published: boolean;
  createdAt: string;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  subject: string;
  type: 'Notes' | 'Past Paper' | 'Website' | 'Video' | 'Other';
  url: string;
  fileName?: string;
  fileSize?: string;
  featured: boolean;
  createdAt: string;
}

export interface SkillCategory { id: string; name: string; order: number; }
export interface SkillItem {
  id: string; name: string; description: string; categoryId: string;
  required: boolean; points: number; isSkillOfWeek: boolean; order: number;
}
export interface SkillCompletion { skillId: string; completedAt: string; evidence: string; verified: boolean; }
export interface LeadershipMember { id: string; role: string; name: string; bio: string; isHeadRole: boolean; order: number; }
export interface Prefect { id: string; name: string; year: 'Year 12' | 'Year 13'; }
export interface SdpSession {
  id: string; name: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
  time: string; room: string; teacher: string; topic: string;
  type: 'Assembly' | 'Workshop' | 'Mentor' | 'External Speaker' | 'Independent Study';
  yearGroup: 'Year 12' | 'Year 13' | 'Both';
  repeat: 'One-off' | 'Weekly' | 'Fortnightly';
  published: boolean; order: number;
}
export interface CalendarEvent {
  id: string; title: string; date: string; endDate?: string;
  type: 'Exam' | 'UCAS' | 'Event' | 'Holiday' | 'SDP' | 'Other';
  description: string; link?: string; createdAt: string;
}
export interface AdminSettings {
  portalTitle: string; contactEmail: string; academicYear: string;
  currentIssueTitle: string; currentIssueUrl: string; currentIssueIntro: string;
  valueOfMonth: string; studentOfMonth: string; teacherOfMonth: string;
}

const KEYS = {
  user: 'sf-user', theme: 'sf-theme',
  announcements: 'sf-announcements', emails: 'sf-emails', resources: 'sf-resources',
  skillCats: 'sf-skill-categories', skillItems: 'sf-skill-items',
  skillOfWeek: 'sf-skill-of-week', completions: 'sf-completions',
  leadership: 'sf-leadership', prefects: 'sf-prefects',
  sdp: 'sf-sdp', calendar: 'sf-calendar', settings: 'sf-settings',
  accounts: 'sf-accounts',
};

const isBrowser = () => typeof window !== 'undefined' && typeof localStorage !== 'undefined';

function load<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch { return fallback; }
}
function save<T>(key: string, value: T): void {
  if (!isBrowser()) return;
  localStorage.setItem(key, JSON.stringify(value));
}
function uid(): string { return Math.random().toString(36).slice(2) + Date.now().toString(36); }

// AUTH
export interface Account { username: string; password: string; role: User['role']; displayName: string; }

const DEFAULT_ACCOUNTS: Account[] = [
  { username: 'admin',          password: 'SixthForm@2024!', role: 'admin',          displayName: 'Admin' },
  { username: 'headofform',     password: 'HoF#Secure2024',  role: 'admin',          displayName: 'Head of Sixth Form' },
  { username: 'deputyhead',     password: 'Deputy#Hub2024',  role: 'admin',          displayName: 'Deputy Head' },
  { username: 'formtutor',      password: 'Tutor@Portal24',  role: 'admin',          displayName: 'Form Tutor' },
  { username: 'headboy',        password: 'HeadBoy#2024',    role: 'student-leader', displayName: 'Head Boy' },
  { username: 'headgirl',       password: 'HeadGirl#2024',   role: 'student-leader', displayName: 'Head Girl' },
  { username: 'deputyheadboy',  password: 'DHB#Leader24',    role: 'student-leader', displayName: 'Deputy Head Boy' },
  { username: 'deputyheadgirl', password: 'DHG#Leader24',    role: 'student-leader', displayName: 'Deputy Head Girl' },
  { username: 'charitylead',    password: 'Charity#Lead24',  role: 'student-leader', displayName: 'Charity Lead' },
  { username: 'sportscaptain',  password: 'Sports#Cap2024',  role: 'student-leader', displayName: 'Sports Captain' },
];

export function getAccounts(): Account[] {
  const list = load<Account[] | null>(KEYS.accounts, null);
  if (!list || list.length === 0) { save(KEYS.accounts, DEFAULT_ACCOUNTS); return DEFAULT_ACCOUNTS; }
  return list;
}
export function saveAccounts(list: Account[]): void { save(KEYS.accounts, list); }
export function addAccount(a: Account): Account | null {
  const list = getAccounts();
  const u = a.username.toLowerCase().trim();
  if (!u || list.some(x => x.username === u)) return null;
  const next: Account = { ...a, username: u };
  saveAccounts([...list, next]);
  return next;
}
export function updateAccount(originalUsername: string, patch: Partial<Account>): boolean {
  const list = getAccounts();
  const idx = list.findIndex(x => x.username === originalUsername);
  if (idx === -1) return false;
  const merged: Account = { ...list[idx], ...patch, username: (patch.username ?? list[idx].username).toLowerCase().trim() };
  if (merged.username !== originalUsername && list.some(x => x.username === merged.username)) return false;
  list[idx] = merged;
  saveAccounts(list);
  return true;
}
export function deleteAccount(username: string): void {
  const list = getAccounts().filter(x => x.username !== username);
  saveAccounts(list);
}

export function login(username: string, password: string): User | null {
  const u = username.toLowerCase().trim();
  const acc = getAccounts().find(a => a.username === u);
  if (!acc || acc.password !== password) return null;
  const user: User = { username: u, role: acc.role, displayName: acc.displayName };
  save(KEYS.user, user);
  return user;
}
export function logout(): void { if (isBrowser()) localStorage.removeItem(KEYS.user); }
export function getUser(): User | null { return load<User | null>(KEYS.user, null); }
export function isAdmin(u: User | null) { return u?.role === 'admin'; }
export function isLeader(u: User | null) { return u?.role === 'admin' || u?.role === 'student-leader'; }

// SEED
export function seedIfEmpty(): void {
  if (!isBrowser()) return;
  if (localStorage.getItem(KEYS.announcements)) return;
  const now = new Date().toISOString();

  save<Announcement[]>(KEYS.announcements, [
    { id: uid(), title: 'UCAS Oxbridge & Medicine Deadline — 15 October', body: 'All Oxbridge and Medicine UCAS applications must be submitted by 15 October. Drop-in clinics every Tuesday lunchtime in Room 204.', tag: 'UCAS', type: 'notice', pinned: true, published: true, createdAt: now, order: 0, linkUrl: 'https://ucas.com', linkLabel: 'Open UCAS' },
    { id: uid(), title: 'Imperial College London Visit — Wednesday Lunchtime', body: 'Join us in the Main Hall on Wednesday lunchtime for a presentation by the Imperial College admissions team.', tag: 'Event', type: 'notice', pinned: true, published: true, createdAt: now, order: 1 },
    { id: uid(), title: 'Charity Bake Sale — Thursday after school! 🍰', body: 'The student leadership team\'s charity bake sale is TOMORROW after school in the common room.', tag: 'Event', type: 'whatsapp', pinned: false, published: true, createdAt: now, order: 2 },
    { id: uid(), title: 'SDP Assembly moved to Thursday Period 1 this week', body: 'Please note the SDP Assembly is in the Main Hall on Thursday Period 1 this week only.', tag: 'SDP', type: 'notice', pinned: false, published: true, createdAt: now, order: 3 },
    { id: uid(), title: 'New weekly email published — Week 6', body: 'The Week 6 weekly email covering UCAS prep, mock schedules and upcoming events is now live.', tag: 'Email', type: 'email-update', pinned: false, published: true, createdAt: now, order: 4 },
  ]);

  save<WeeklyEmail[]>(KEYS.emails, [
    { id: uid(), weekNumber: 'Week 6', dateSent: '2024-10-14', subject: 'UCAS prep, mock schedules & upcoming events', tags: ['UCAS','Mocks','Events'], published: true, createdAt: now,
      body: `Dear Sixth Form students,\n\nA reminder that UCAS applications for Oxbridge and Medicine close on 15 October. Please ensure your personal statement has been reviewed by your form tutor.\n\nThe Year 13 mock exam timetable has now been published.\n\nImperial College London will be visiting on Wednesday during lunchtime in the Main Hall.\n\nBest wishes,\nThe Sixth Form Team` },
    { id: uid(), weekNumber: 'Week 5', dateSent: '2024-10-07', subject: 'Open Days, personal statement tips & enrichment', tags: ['UCAS','Events','Enrichment'], published: true, createdAt: now,
      body: `Dear Sixth Form students,\n\nUniversity open day season is in full swing. Personal statement workshop notes are now available on the Resources page.\n\nOur annual enrichment fair takes place in two weeks.\n\nBest wishes,\nThe Sixth Form Team` },
    { id: uid(), weekNumber: 'Week 4', dateSent: '2024-09-30', subject: 'Freshers\' reflections, study skills & Oxbridge prep', tags: ['Study Skills','Oxbridge'], published: true, createdAt: now,
      body: `Dear Sixth Form students,\n\nFour weeks in — we hope you're settling into the rhythm of Sixth Form life. The Oxbridge preparation programme starts next week.\n\nStudy skills resources are now available on the Resources page.\n\nBest wishes,\nThe Sixth Form Team` },
  ]);

  save<Resource[]>(KEYS.resources, [
    { id: uid(), title: 'A-Level Maths Topicals 2024', description: 'Complete set of past paper questions organised by topic with mark schemes.', subject: 'Mathematics', type: 'Past Paper', url: 'https://www.physicsandmathstutor.com/maths-revision/a-level/', featured: true, createdAt: now },
    { id: uid(), title: 'Isaac Physics — Free Problem Solving', description: 'Free problem-solving platform recommended for Physics and Maths.', subject: 'Physics', type: 'Website', url: 'https://isaacphysics.org', featured: true, createdAt: now },
    { id: uid(), title: 'English Literature — Revision Notes', description: 'Comprehensive notes covering all set texts with essay frameworks.', subject: 'English Literature', type: 'Notes', url: 'https://www.sparknotes.com', featured: false, createdAt: now },
    { id: uid(), title: 'History — Cold War Notes & Timeline', description: 'Supplementary notes with timeline, key figures and essay plans for the Cold War unit.', subject: 'History', type: 'Notes', url: 'https://www.historylearningsite.co.uk', featured: false, createdAt: now },
    { id: uid(), title: 'Corbett Maths — A-Level Videos', description: 'YouTube playlist of every A-Level Maths topic with worked examples.', subject: 'Mathematics', type: 'Video', url: 'https://corbettmaths.com/a-level/', featured: false, createdAt: now },
    { id: uid(), title: 'Biology — AQA Specification Checklist', description: 'Tick off every spec point as you revise. AQA A-Level Biology.', subject: 'Biology', type: 'Past Paper', url: 'https://www.aqa.org.uk/subjects/science/a-level/biology-7402', featured: false, createdAt: now },
    { id: uid(), title: 'Economics — Tutor2U Revision', description: 'Free revision guides for all A-Level Economics topics.', subject: 'Economics', type: 'Website', url: 'https://www.tutor2u.net/economics/a-level', featured: true, createdAt: now },
    { id: uid(), title: 'UCAS Personal Statement Guide 2025', description: 'Step-by-step guide to writing your UCAS personal statement.', subject: 'UCAS', type: 'Notes', url: 'https://www.ucas.com/undergraduate/applying-university/writing-personal-statement', featured: true, createdAt: now },
  ]);

  save<SkillCategory[]>(KEYS.skillCats, [
    { id: 'cat-academic', name: 'Academic Skills', order: 0 },
    { id: 'cat-leadership', name: 'Leadership Skills', order: 1 },
    { id: 'cat-digital', name: 'Digital Skills', order: 2 },
    { id: 'cat-communication', name: 'Communication Skills', order: 3 },
    { id: 'cat-community', name: 'Community Skills', order: 4 },
  ]);

  save<SkillItem[]>(KEYS.skillItems, [
    { id: uid(), name: 'Active Recall & Revision Techniques', description: 'Demonstrate use of flashcards, past papers, or spaced repetition.', categoryId: 'cat-academic', required: true, points: 10, isSkillOfWeek: true, order: 0 },
    { id: uid(), name: 'Extended Essay / EPQ Research', description: 'Complete an extended research task of at least 2000 words.', categoryId: 'cat-academic', required: true, points: 25, isSkillOfWeek: false, order: 1 },
    { id: uid(), name: 'Academic Reading Log', description: 'Read and log 5 academic texts relevant to your A-Level subjects.', categoryId: 'cat-academic', required: false, points: 15, isSkillOfWeek: false, order: 2 },
    { id: uid(), name: 'Led a Team Activity', description: 'Take the lead on a group project, society, or event.', categoryId: 'cat-leadership', required: false, points: 20, isSkillOfWeek: false, order: 0 },
    { id: uid(), name: 'Mentoring / Peer Support', description: 'Support a younger student or peer for at least one full term.', categoryId: 'cat-leadership', required: false, points: 20, isSkillOfWeek: false, order: 1 },
    { id: uid(), name: 'Organised a School Event', description: 'Plan and coordinate a school event from start to finish.', categoryId: 'cat-leadership', required: false, points: 25, isSkillOfWeek: false, order: 2 },
    { id: uid(), name: 'Built a Digital Project', description: 'Create a website, app, spreadsheet tool, or digital resource.', categoryId: 'cat-digital', required: false, points: 15, isSkillOfWeek: false, order: 0 },
    { id: uid(), name: 'Online Safety Awareness', description: 'Complete the school\'s online safety module and quiz.', categoryId: 'cat-digital', required: true, points: 5, isSkillOfWeek: false, order: 1 },
    { id: uid(), name: 'Public Speaking', description: 'Deliver a presentation to an audience of at least 10 people.', categoryId: 'cat-communication', required: false, points: 20, isSkillOfWeek: false, order: 0 },
    { id: uid(), name: 'Debate or Mock Trial', description: 'Participate in a formal debate, mock trial, or Model UN.', categoryId: 'cat-communication', required: false, points: 15, isSkillOfWeek: false, order: 1 },
    { id: uid(), name: 'Volunteering (10+ hours)', description: 'Complete at least 10 hours of volunteering in the community.', categoryId: 'cat-community', required: false, points: 20, isSkillOfWeek: false, order: 0 },
    { id: uid(), name: 'Charity Fundraising', description: 'Contribute to or organise a fundraising initiative.', categoryId: 'cat-community', required: false, points: 15, isSkillOfWeek: false, order: 1 },
  ]);

  save<LeadershipMember[]>(KEYS.leadership, [
    { id: uid(), role: 'Head Boy', name: 'James Adeyemi', bio: 'Representing every voice in our Sixth Form community.', isHeadRole: true, order: 0 },
    { id: uid(), role: 'Head Girl', name: 'Sofia Patel', bio: 'Building bridges between students and staff.', isHeadRole: true, order: 1 },
    { id: uid(), role: 'Deputy Head Boy', name: 'Kofi Owusu', bio: 'Driving excellence and wellbeing across Year 12 and 13.', isHeadRole: false, order: 2 },
    { id: uid(), role: 'Deputy Head Girl', name: 'Layla Nasir', bio: 'Here to amplify your ideas and make Sixth Form inclusive.', isHeadRole: false, order: 3 },
    { id: uid(), role: 'Charity Lead', name: 'Theo Williams', bio: 'Leading our fundraising and community outreach.', isHeadRole: false, order: 4 },
    { id: uid(), role: 'Sports Captain', name: 'Marcus Reid', bio: 'Promoting sport, fitness and healthy competition.', isHeadRole: false, order: 5 },
    { id: uid(), role: 'Arts Captain', name: 'Erin Roberts', bio: 'Celebrating creativity, culture and the arts.', isHeadRole: false, order: 6 },
    { id: uid(), role: 'Community Lead', name: 'Priya Sharma', bio: 'Connecting Sixth Form with the wider community.', isHeadRole: false, order: 7 },
  ]);

  save<Prefect[]>(KEYS.prefects, [
    { id: uid(), name: 'Aisha Mohammed', year: 'Year 12' },
    { id: uid(), name: 'Ben Clarke', year: 'Year 13' },
    { id: uid(), name: 'Chloe Thompson', year: 'Year 12' },
    { id: uid(), name: 'Daniel Lee', year: 'Year 13' },
    { id: uid(), name: 'Fatima Hassan', year: 'Year 12' },
    { id: uid(), name: 'George Mitchell', year: 'Year 13' },
    { id: uid(), name: 'Hannah Park', year: 'Year 12' },
    { id: uid(), name: 'Ibrahim Sow', year: 'Year 12' },
    { id: uid(), name: 'Jasmine Blake', year: 'Year 13' },
    { id: uid(), name: 'Kai Nakamura', year: 'Year 12' },
    { id: uid(), name: 'Lily Chen', year: 'Year 13' },
    { id: uid(), name: 'Max Okafor', year: 'Year 12' },
  ]);

  save<SdpSession[]>(KEYS.sdp, [
    { id: uid(), name: 'Sixth Form Assembly', day: 'Thursday', time: 'Period 1 (8:45–9:30)', room: 'Main Hall', teacher: 'All Staff', topic: 'Weekly updates and key notices', type: 'Assembly', yearGroup: 'Both', repeat: 'Weekly', published: true, order: 0 },
    { id: uid(), name: 'UCAS Workshop', day: 'Tuesday', time: 'Period 3 (11:00–11:45)', room: 'Room 104', teacher: 'Mr Ahmed', topic: 'Personal statement writing and review', type: 'Workshop', yearGroup: 'Year 13', repeat: 'Weekly', published: true, order: 1 },
    { id: uid(), name: 'Mentor Session', day: 'Monday', time: 'Period 1 (8:45–9:30)', room: 'Form Rooms', teacher: 'Form Tutors', topic: 'Wellbeing check-in and academic review', type: 'Mentor', yearGroup: 'Both', repeat: 'Weekly', published: true, order: 2 },
    { id: uid(), name: 'Imperial College Talk', day: 'Wednesday', time: 'Lunchtime (13:00–13:45)', room: 'Main Hall', teacher: 'External', topic: 'Engineering and STEM pathways', type: 'External Speaker', yearGroup: 'Both', repeat: 'One-off', published: true, order: 3 },
    { id: uid(), name: 'Study Skills Session', day: 'Thursday', time: 'Period 5 (14:15–15:00)', room: 'Room 302', teacher: 'Dr Chen', topic: 'Exam technique and revision strategies', type: 'Workshop', yearGroup: 'Year 12', repeat: 'Fortnightly', published: true, order: 4 },
    { id: uid(), name: 'PSHE & Wellbeing', day: 'Friday', time: 'Period 2 (9:35–10:20)', room: 'Room 201', teacher: 'Mrs Hughes', topic: 'Mental health, relationships and futures', type: 'Mentor', yearGroup: 'Both', repeat: 'Weekly', published: true, order: 5 },
  ]);

  save<CalendarEvent[]>(KEYS.calendar, [
    { id: uid(), title: 'UCAS Oxbridge & Medicine Deadline', date: '2024-10-15', type: 'UCAS', description: 'All Oxbridge and Medicine UCAS applications must be submitted today.', link: 'https://ucas.com', createdAt: now },
    { id: uid(), title: 'Imperial College London Visit', date: '2024-10-16', type: 'Event', description: 'Admissions talk in the Main Hall during lunchtime.', createdAt: now },
    { id: uid(), title: 'Y13 Mock Exams Begin', date: '2024-10-21', type: 'Exam', description: 'Year 13 mock examination period begins.', createdAt: now },
    { id: uid(), title: 'Half Term Holiday', date: '2024-10-25', endDate: '2024-11-01', type: 'Holiday', description: 'School closed for half term.', createdAt: now },
    { id: uid(), title: 'Cambridge Engineering Masterclass', date: '2024-11-06', type: 'Event', description: 'Hosted online by Cambridge.', createdAt: now },
    { id: uid(), title: 'UCAS General Deadline', date: '2025-01-29', type: 'UCAS', description: 'Deadline for all remaining UCAS undergraduate applications.', link: 'https://ucas.com', createdAt: now },
    { id: uid(), title: 'A-Level Exams Begin', date: '2025-05-12', type: 'Exam', description: 'A-Level examination series begins for Year 13.', createdAt: now },
    { id: uid(), title: 'Y12 End of Year Exams', date: '2025-06-09', type: 'Exam', description: 'Year 12 internal examinations begin.', createdAt: now },
    { id: uid(), title: 'Summer Holiday Begins', date: '2025-07-18', type: 'Holiday', description: 'Last day of the academic year.', createdAt: now },
  ]);

  save<AdminSettings>(KEYS.settings, {
    portalTitle: 'Sixth Form Hub',
    contactEmail: 'sixthform@school.ac.uk',
    academicYear: '2024–25',
    currentIssueTitle: 'The Sixth Form Monthly — October 2024',
    currentIssueUrl: 'https://www.w3.org/WAI/WCAG21/Techniques/pdf/PDF1',
    currentIssueIntro: 'This month: UCAS special, enrichment opportunities, student spotlights, and the results of our charity drive.',
    valueOfMonth: 'Resilience — the strength to keep going when things get hard.',
    studentOfMonth: 'Aisha Mohammed (Year 12) — for outstanding contribution to the school community.',
    teacherOfMonth: 'Dr Chen (Mathematics) — for going above and beyond to support Year 13 students.',
  });
}

// ANNOUNCEMENTS
export function getAnnouncements() { return load<Announcement[]>(KEYS.announcements, []).filter(a => a.published).sort((a,b)=>a.order-b.order); }
export function getAllAnnouncements() { return load<Announcement[]>(KEYS.announcements, []).sort((a,b)=>a.order-b.order); }
export function saveAnnouncements(items: Announcement[]) { save(KEYS.announcements, items); }
export function addAnnouncement(item: Omit<Announcement,'id'|'createdAt'|'order'>) {
  const all = getAllAnnouncements();
  all.unshift({ ...item, id: uid(), createdAt: new Date().toISOString(), order: 0 });
  all.forEach((a,i)=>a.order=i);
  saveAnnouncements(all);
}
export function updateAnnouncement(id: string, patch: Partial<Announcement>) {
  saveAnnouncements(getAllAnnouncements().map(a=>a.id===id?{...a,...patch}:a));
}
export function deleteAnnouncement(id: string) { saveAnnouncements(getAllAnnouncements().filter(a=>a.id!==id)); }

// EMAILS
export function getEmails() { return load<WeeklyEmail[]>(KEYS.emails, []).filter(e=>e.published).sort((a,b)=>new Date(b.dateSent).getTime()-new Date(a.dateSent).getTime()); }
export function getAllEmails() { return load<WeeklyEmail[]>(KEYS.emails, []).sort((a,b)=>new Date(b.dateSent).getTime()-new Date(a.dateSent).getTime()); }
export function saveEmails(items: WeeklyEmail[]) { save(KEYS.emails, items); }
export function addEmail(item: Omit<WeeklyEmail,'id'|'createdAt'>) {
  const all = getAllEmails();
  all.unshift({ ...item, id: uid(), createdAt: new Date().toISOString() });
  saveEmails(all);
}
export function updateEmail(id: string, patch: Partial<WeeklyEmail>) { saveEmails(getAllEmails().map(e=>e.id===id?{...e,...patch}:e)); }
export function deleteEmail(id: string) { saveEmails(getAllEmails().filter(e=>e.id!==id)); }

// RESOURCES
export function getResources(subject?: string) {
  let items = load<Resource[]>(KEYS.resources, []).sort((a,b)=>(b.featured?1:0)-(a.featured?1:0) || new Date(b.createdAt).getTime()-new Date(a.createdAt).getTime());
  if (subject && subject !== 'All') items = items.filter(r=>r.subject===subject);
  return items;
}
export function getAllResources() { return load<Resource[]>(KEYS.resources, []); }
export function saveResources(items: Resource[]) { save(KEYS.resources, items); }
export function addResource(item: Omit<Resource,'id'|'createdAt'>) {
  const all = getAllResources();
  all.unshift({ ...item, id: uid(), createdAt: new Date().toISOString() });
  saveResources(all);
}
export function updateResource(id: string, patch: Partial<Resource>) { saveResources(getAllResources().map(r=>r.id===id?{...r,...patch}:r)); }
export function deleteResource(id: string) { saveResources(getAllResources().filter(r=>r.id!==id)); }

// SKILLS
export function getSkillCategories() { return load<SkillCategory[]>(KEYS.skillCats, []).sort((a,b)=>a.order-b.order); }
export function saveSkillCategories(items: SkillCategory[]) { save(KEYS.skillCats, items); }
export function addSkillCategory(name: string) {
  const all = getSkillCategories();
  all.push({ id: uid(), name, order: all.length });
  saveSkillCategories(all);
}
export function deleteSkillCategory(id: string) { saveSkillCategories(getSkillCategories().filter(c=>c.id!==id)); }

export function getSkillItems(categoryId?: string) {
  const items = load<SkillItem[]>(KEYS.skillItems, []).sort((a,b)=>a.order-b.order);
  return categoryId ? items.filter(s=>s.categoryId===categoryId) : items;
}
export function saveSkillItems(items: SkillItem[]) { save(KEYS.skillItems, items); }
export function getSkillOfWeek() { return getSkillItems().find(s=>s.isSkillOfWeek) || null; }
export function setSkillOfWeek(id: string) { saveSkillItems(getSkillItems().map(s=>({...s, isSkillOfWeek: s.id===id}))); }
export function addSkillItem(item: Omit<SkillItem,'id'|'order'>) {
  const all = getSkillItems();
  const catItems = all.filter(s=>s.categoryId===item.categoryId);
  all.push({ ...item, id: uid(), order: catItems.length });
  saveSkillItems(all);
}
export function updateSkillItem(id: string, patch: Partial<SkillItem>) { saveSkillItems(getSkillItems().map(s=>s.id===id?{...s,...patch}:s)); }
export function deleteSkillItem(id: string) { saveSkillItems(getSkillItems().filter(s=>s.id!==id)); }

// COMPLETIONS
export function getCompletions(username: string) { return load<SkillCompletion[]>(`${KEYS.completions}-${username}`, []); }
export function saveCompletions(username: string, items: SkillCompletion[]) { save(`${KEYS.completions}-${username}`, items); }
export function toggleCompletion(username: string, skillId: string, evidence = '') {
  const all = getCompletions(username);
  const ex = all.find(c=>c.skillId===skillId);
  if (ex) saveCompletions(username, all.filter(c=>c.skillId!==skillId));
  else { all.push({ skillId, completedAt: new Date().toISOString(), evidence, verified: false }); saveCompletions(username, all); }
}
export function updateEvidence(username: string, skillId: string, evidence: string) {
  saveCompletions(username, getCompletions(username).map(c=>c.skillId===skillId?{...c, evidence}:c));
}
export function verifyCompletion(username: string, skillId: string) {
  saveCompletions(username, getCompletions(username).map(c=>c.skillId===skillId?{...c, verified: true}:c));
}

// LEADERSHIP
export function getLeadershipMembers() { return load<LeadershipMember[]>(KEYS.leadership, []).sort((a,b)=>a.order-b.order); }
export function saveLeadershipMembers(items: LeadershipMember[]) { save(KEYS.leadership, items); }
export function addLeadershipMember(item: Omit<LeadershipMember,'id'|'order'>) {
  const all = getLeadershipMembers();
  all.push({ ...item, id: uid(), order: all.length });
  saveLeadershipMembers(all);
}
export function updateLeadershipMember(id: string, patch: Partial<LeadershipMember>) {
  saveLeadershipMembers(getLeadershipMembers().map(m=>m.id===id?{...m,...patch}:m));
}
export function deleteLeadershipMember(id: string) { saveLeadershipMembers(getLeadershipMembers().filter(m=>m.id!==id)); }

// PREFECTS
export function getPrefects() { return load<Prefect[]>(KEYS.prefects, []); }
export function savePrefects(items: Prefect[]) { save(KEYS.prefects, items); }
export function addPrefect(name: string, year: Prefect['year']) {
  const all = getPrefects();
  all.push({ id: uid(), name, year });
  savePrefects(all);
}
export function deletePrefect(id: string) { savePrefects(getPrefects().filter(p=>p.id!==id)); }

// SDP
export function getSdpSessions(yearGroup?: string) {
  let items = load<SdpSession[]>(KEYS.sdp, []).filter(s=>s.published).sort((a,b)=>a.order-b.order);
  if (yearGroup && yearGroup !== 'Both') items = items.filter(s=>s.yearGroup===yearGroup || s.yearGroup==='Both');
  return items;
}
export function getAllSdpSessions() { return load<SdpSession[]>(KEYS.sdp, []); }
export function saveSdpSessions(items: SdpSession[]) { save(KEYS.sdp, items); }
export function addSdpSession(item: Omit<SdpSession,'id'|'order'>) {
  const all = getAllSdpSessions();
  all.push({ ...item, id: uid(), order: all.length });
  saveSdpSessions(all);
}
export function updateSdpSession(id: string, patch: Partial<SdpSession>) { saveSdpSessions(getAllSdpSessions().map(s=>s.id===id?{...s,...patch}:s)); }
export function deleteSdpSession(id: string) { saveSdpSessions(getAllSdpSessions().filter(s=>s.id!==id)); }

// CALENDAR
export function getCalendarEvents() { return load<CalendarEvent[]>(KEYS.calendar, []).sort((a,b)=>a.date.localeCompare(b.date)); }
export function saveCalendarEvents(items: CalendarEvent[]) { save(KEYS.calendar, items); }
export function addCalendarEvent(item: Omit<CalendarEvent,'id'|'createdAt'>) {
  const all = getCalendarEvents();
  all.push({ ...item, id: uid(), createdAt: new Date().toISOString() });
  saveCalendarEvents(all.sort((a,b)=>a.date.localeCompare(b.date)));
}
export function updateCalendarEvent(id: string, patch: Partial<CalendarEvent>) { saveCalendarEvents(getCalendarEvents().map(e=>e.id===id?{...e,...patch}:e)); }
export function deleteCalendarEvent(id: string) { saveCalendarEvents(getCalendarEvents().filter(e=>e.id!==id)); }

// SETTINGS
export function getSettings(): AdminSettings {
  return load<AdminSettings>(KEYS.settings, {
    portalTitle: 'Sixth Form Hub', contactEmail: '', academicYear: '2024–25',
    currentIssueTitle: '', currentIssueUrl: '', currentIssueIntro: '',
    valueOfMonth: '', studentOfMonth: '', teacherOfMonth: '',
  });
}
export function saveSettings(s: AdminSettings) { save(KEYS.settings, s); }

// Helpers
export function subjectColor(subject: string): string {
  const palette = ['#9d3d3d','#c99216','#1a2d5a','#7a2c2c','#a07410','#3d6b9d','#5a8a3d','#8a3d6b','#9d6b3d','#3d8a8a'];
  let h = 0;
  for (let i=0;i<subject.length;i++) h = (h*31 + subject.charCodeAt(i)) & 0xffff;
  return palette[h % palette.length];
}
export function timeAgo(iso: string): string {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff/86400)}d ago`;
  return new Date(iso).toLocaleDateString('en-GB');
}
