import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { type User, getUser, logout as doLogout } from '@/lib/data';

interface AuthCtx { user: User | null; setUser: (u: User | null) => void; logout: () => void; }
const Ctx = createContext<AuthCtx>({ user: null, setUser: () => {}, logout: () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => { setUser(getUser()); }, []);
  const logout = () => { doLogout(); setUser(null); };
  return <Ctx.Provider value={{ user, setUser, logout }}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
