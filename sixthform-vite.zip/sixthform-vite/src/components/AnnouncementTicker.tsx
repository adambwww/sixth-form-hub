import { useEffect, useState } from 'react';
import { getAnnouncements } from '@/lib/data';

export function AnnouncementTicker() {
  const [items, setItems] = useState<string[]>([]);
  useEffect(() => {
    setItems(getAnnouncements().filter(a => a.pinned).map(a => a.title));
  }, []);
  if (!items.length) return null;
  const text = items.join('  ·  ');
  return (
    <div className="ticker-strip overflow-hidden bg-gradient-burgundy text-white">
      <div className="flex whitespace-nowrap py-2 text-sm font-medium animate-marquee">
        <span className="px-6">{text}  ·  {text}</span>
        <span className="px-6" aria-hidden="true">{text}  ·  {text}</span>
      </div>
    </div>
  );
}
