
export function PageHero({ eyebrow, title, subtitle, variant = 'burgundy' }: { eyebrow?: string; title: string; subtitle?: string; variant?: 'burgundy' | 'navy' | 'gold' | 'split' }) {
  const bg = variant === 'navy' ? 'bg-gradient-navy' : variant === 'gold' ? 'bg-gradient-gold' : variant === 'split' ? 'bg-gradient-hero' : 'bg-gradient-burgundy';
  return (
    <section className={`relative overflow-hidden ${bg} text-white`}>
      <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl animate-float-slow" />
      <div className="pointer-events-none absolute -left-20 bottom-0 h-64 w-64 rounded-full bg-gold/20 blur-3xl animate-float-fast" />
      <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20">
        <div>
          {eyebrow && <div className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-white/70">{eyebrow}</div>}
          <h1 className="max-w-3xl font-display text-4xl font-bold leading-[1.05] sm:text-5xl lg:text-6xl">{title}</h1>
          {subtitle && <p className="mt-4 max-w-2xl text-lg text-white/80">{subtitle}</p>}
        </div>
      </div>
    </section>
  );
}
