import { useState, useEffect } from 'react';
import { Link, useRouterState, useNavigate } from '@tanstack/react-router';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Sun, Moon, Menu, X, ChevronDown, Sparkles, LogIn, LogOut, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/context/AuthContext';
import { SearchOverlay } from './SearchOverlay';

export const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/student-space', label: 'Student Space' },
  { to: '/student-leadership', label: 'Leadership' },
  { to: '/skill-checks', label: 'Skill Checks' },
  { to: '/resources', label: 'Resources' },
  { to: '/weekly-emails', label: 'Weekly Emails' },
  { to: '/sdp-timetables', label: 'SDP' },
  { to: '/academic-calendar', label: 'Calendar' },
  { to: '/year-12', label: 'Year 12' },
  { to: '/year-13', label: 'Year 13' },
  { to: '/timeline', label: 'Journey' },
  { to: '/opportunities', label: 'Opportunities' },
  { to: '/essentials', label: 'Essentials' },
] as const;

export function SiteNav() {
  const pathname = useRouterState({ select: s => s.location.pathname });
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [dark, setDark] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('sf-theme');
    const prefers = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const isDark = stored === 'dark' || (!stored && prefers);
    document.documentElement.classList.toggle('dark', isDark);
    setDark(isDark);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const toggleDark = () => {
    const next = !dark;
    document.documentElement.classList.toggle('dark', next);
    localStorage.setItem('sf-theme', next ? 'dark' : 'light');
    setDark(next);
  };

  const inline = NAV_LINKS.slice(0, 7);
  const overflow = NAV_LINKS.slice(7);

  return (
    <>
      <header className="site-nav sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-burgundy text-white font-display font-bold shadow-soft">
              SF
            </div>
            <span className="hidden font-display text-lg font-bold tracking-tight sm:inline">Sixth Form Hub</span>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {inline.map(link => (
              <NavLink key={link.to} to={link.to} label={link.label} active={pathname === link.to} />
            ))}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-muted hover:text-foreground">
                  More <ChevronDown className="h-3.5 w-3.5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {overflow.map(link => (
                  <DropdownMenuItem key={link.to} asChild>
                    <Link to={link.to}>{link.label}</Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          <div className="flex items-center gap-1">
            <button aria-label="Search" onClick={() => setSearchOpen(true)} className="hidden items-center gap-2 rounded-md border border-border bg-muted px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-accent md:flex">
              <Search className="h-3.5 w-3.5" /> Search <kbd className="ml-2 rounded bg-background px-1.5 py-0.5 text-[10px]">⌘K</kbd>
            </button>
            <button aria-label="Toggle dark mode" onClick={toggleDark} className="rounded-md p-2 transition-colors hover:bg-muted">
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" className="hidden bg-gradient-gold text-white hover:opacity-90 md:inline-flex">
                    <Sparkles className="mr-1 h-3.5 w-3.5" /> {user.displayName}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {user.role === 'admin' && (
                    <DropdownMenuItem onClick={() => navigate({ to: '/admin' })}>
                      <Shield className="mr-2 h-4 w-4" /> Admin Panel
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={() => { logout(); navigate({ to: '/' }); }}>
                    <LogOut className="mr-2 h-4 w-4" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/login" className="hidden md:inline-flex">
                <Button size="sm" className="bg-gradient-gold text-white hover:opacity-90">
                  <LogIn className="mr-1 h-3.5 w-3.5" /> Sign in
                </Button>
              </Link>
            )}
            <button aria-label="Open menu" onClick={() => setMobileOpen(true)} className="rounded-md p-2 transition-colors hover:bg-muted lg:hidden">
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div className="fixed inset-0 z-[60] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
            <motion.div className="absolute right-0 top-0 h-full w-[84%] max-w-sm overflow-y-auto bg-background p-6 shadow-2xl" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 24, stiffness: 220 }}>
              <div className="mb-6 flex items-center justify-between">
                <span className="font-display text-lg font-bold">Menu</span>
                <button aria-label="Close menu" onClick={() => setMobileOpen(false)} className="rounded-md p-2 hover:bg-muted"><X className="h-5 w-5" /></button>
              </div>
              <nav className="flex flex-col gap-1">
                {NAV_LINKS.map(link => (
                  <Link key={link.to} to={link.to} onClick={() => setMobileOpen(false)} className={`rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${pathname === link.to ? 'bg-burgundy-soft text-burgundy' : 'hover:bg-muted'}`}>
                    {link.label}
                  </Link>
                ))}
                <div className="my-3 h-px bg-border" />
                {user ? (
                  <>
                    {user.role === 'admin' && (
                      <Link to="/admin" onClick={() => setMobileOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-muted">Admin Panel</Link>
                    )}
                    <button onClick={() => { logout(); setMobileOpen(false); navigate({ to: '/' }); }} className="rounded-lg px-3 py-2.5 text-left text-sm font-medium text-destructive hover:bg-muted">Sign out</button>
                  </>
                ) : (
                  <Link to="/login" onClick={() => setMobileOpen(false)} className="rounded-lg bg-gradient-gold px-3 py-2.5 text-center text-sm font-medium text-white">Sign in</Link>
                )}
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <SearchOverlay open={searchOpen} onOpenChange={setSearchOpen} />
    </>
  );
}

function NavLink({ to, label, active }: { to: string; label: string; active: boolean }) {
  return (
    <Link to={to} className="relative rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:text-foreground">
      {label}
      {active && (
        <motion.span layoutId="nav-underline" className="absolute inset-x-2 -bottom-0.5 h-0.5 rounded-full bg-gradient-to-r from-burgundy to-gold" />
      )}
    </Link>
  );
}
