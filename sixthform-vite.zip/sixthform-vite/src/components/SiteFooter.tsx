import { Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { getSettings, type AdminSettings } from '@/lib/data';

export function SiteFooter() {
  const [settings, setSettings] = useState<AdminSettings | null>(null);
  useEffect(() => { setSettings(getSettings()); }, []);

  return (
    <footer className="site-footer mt-20 border-t border-border bg-muted/40">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="mb-3 flex items-center gap-2">
              <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-burgundy font-display font-bold text-white">SF</div>
              <span className="font-display text-lg font-bold">Sixth Form Hub</span>
            </div>
            <p className="text-sm text-muted-foreground">Your home for everything Sixth Form. {settings?.academicYear}.</p>
          </div>
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wide text-foreground/70">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/resources" className="hover:text-burgundy">Resources</Link></li>
              <li><Link to="/weekly-emails" className="hover:text-burgundy">Weekly Emails</Link></li>
              <li><Link to="/academic-calendar" className="hover:text-burgundy">Calendar</Link></li>
              <li><Link to="/sdp-timetables" className="hover:text-burgundy">SDP Timetables</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wide text-foreground/70">Year Groups</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/year-12" className="hover:text-burgundy">Year 12</Link></li>
              <li><Link to="/year-13" className="hover:text-burgundy">Year 13</Link></li>
              <li><Link to="/opportunities" className="hover:text-burgundy">Opportunities</Link></li>
              <li><Link to="/timeline" className="hover:text-burgundy">Journey</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="mb-3 text-xs font-semibold uppercase tracking-wide text-foreground/70">Contact</h4>
            <p className="text-sm text-muted-foreground">{settings?.contactEmail || 'sixthform@school.ac.uk'}</p>
            <Link to="/login" className="mt-3 inline-block text-xs text-muted-foreground hover:text-burgundy">Staff sign in →</Link>
          </div>
        </div>
        <div className="mt-10 border-t border-border pt-6 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Sixth Form Hub. Built for our students.
        </div>
      </div>
    </footer>
  );
}
