import { useEffect, useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { Search } from 'lucide-react';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { NAV_LINKS } from './SiteNav';
import { getAllResources, getAllEmails, getAllAnnouncements, getCalendarEvents } from '@/lib/data';

export function SearchOverlay({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const navigate = useNavigate();
  const [data, setData] = useState<{ resources: any[]; emails: any[]; announcements: any[]; events: any[] }>({ resources: [], emails: [], announcements: [], events: [] });

  useEffect(() => {
    if (open) {
      setData({
        resources: getAllResources(),
        emails: getAllEmails(),
        announcements: getAllAnnouncements(),
        events: getCalendarEvents(),
      });
    }
  }, [open]);

  const go = (to: string) => { onOpenChange(false); navigate({ to }); };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="search-overlay max-w-2xl overflow-hidden p-0">
        <Command>
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <CommandInput placeholder="Search pages, resources, emails, events…" className="border-0 focus:ring-0" />
          </div>
          <CommandList className="max-h-[400px]">
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup heading="Pages">
              {NAV_LINKS.map(l => (
                <CommandItem key={l.to} onSelect={() => go(l.to)}>{l.label}</CommandItem>
              ))}
            </CommandGroup>
            {data.resources.length > 0 && (
              <CommandGroup heading="Resources">
                {data.resources.slice(0, 8).map(r => (
                  <CommandItem key={r.id} onSelect={() => go('/resources')}>{r.title}</CommandItem>
                ))}
              </CommandGroup>
            )}
            {data.emails.length > 0 && (
              <CommandGroup heading="Weekly Emails">
                {data.emails.slice(0, 5).map(e => (
                  <CommandItem key={e.id} onSelect={() => go('/weekly-emails')}>{e.weekNumber} — {e.subject}</CommandItem>
                ))}
              </CommandGroup>
            )}
            {data.events.length > 0 && (
              <CommandGroup heading="Calendar">
                {data.events.slice(0, 6).map(ev => (
                  <CommandItem key={ev.id} onSelect={() => go('/academic-calendar')}>{ev.date} — {ev.title}</CommandItem>
                ))}
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
